#include "ChatServer.h"


ChatServer::~ChatServer()
{
}

bool ChatServer::init(uint16_t port)
{
    int result;
    WSADATA wsaData;    //make sure to always cleanup

    //WSA Startup 
    result = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (result != 0)
    {
        printf("WSAStartup failed with error: %d\n", result);
        return false;
    }

    //Socket Creation
    
    //AF_INET = IPv4 connection
    //SOCK_STREAM = TCP Connection
    //IPPROTO_TCP = TCP Protocol
    listenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    
    if (listenSocket == INVALID_SOCKET)
    {
        printf("Failed to create socket\n");
        WSACleanup();
        return false;
    }

    ////Binding
    sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET; // give it a family :)
    serverAddress.sin_addr.S_un.S_addr = INADDR_ANY; // accept any address
    serverAddress.sin_port = htons(port); // Give it the port
    result = bind(listenSocket, (SOCKADDR*)&serverAddress, sizeof(serverAddress));

    if (result == SOCKET_ERROR)
        return false;

    //start listening
    if (listen(listenSocket, 4) == SOCKET_ERROR)
        return false;

    FD_ZERO(&masterSet);
    FD_SET(listenSocket, &masterSet);
    numRegistered = 0;

    for (size_t i = 0; i < 4; i++)
    {
        availableID[i] = true;
    }

    return true;
}

bool ChatServer::run()
{
    //Set the clients
    for (Client& client : clients)
        FD_SET(client.socket, &masterSet);

    //Create a copy to read from
    fd_set readSet;
    readSet = masterSet;

    //Check who is ready
    int numReady = select(0, &readSet, NULL, NULL, NULL);

    if (FD_ISSET(listenSocket, &readSet))
    {
        SOCKET connection;
        connection = accept(listenSocket, NULL, NULL);

        //only continue if the socket is valid
        if (connection != INVALID_SOCKET)
        {
            //add the client into the client list
            Client newClient(connection);
            clients.push_back(newClient);
        }
    }

    for (Client& client: clients )
    {
        if (FD_ISSET(client.socket, &readSet))
        {
            int length = 0;
            int bytesReceived = recMessage(client.socket, (char*)&length, 2, 0);
            char* buffer = new char[length];
            bytesReceived = recMessage(client.socket, buffer, length, 0);
            int pos = 1;
            string message(buffer);
            string returnMessage;

            //Check for codes
            if (message[0] == '$')
            {
                //Check for register
                if (message.substr(0, 9) == "$register")
                {

                    //check if there are available id
                    if (numRegistered < 4)
                    {
                        client.registered = true;
                        client.name = message.substr(9, message.size());
                        numRegistered++;
                        
                        //Send back SV_SUCCESS
                        returnMessage += SV_SUCCESS;
                        for (int i = 0; i < 4; i++)
                        {
                            if (availableID[i])
                            {
                                returnMessage.push_back((char)i);
                                availableID[i] = false;
                                client.id = i;
                                break;
                            }
                        }
                    }
                    else
                    {
                        //Send back SV_FULL
                        returnMessage.push_back(SV_FULL);
                    }
                }
                else if (message.substr(0,8) == "$getlist")
                {
                    if (numRegistered == 0)
                    {
                        returnMessage.push_back(SV_EMPTY);
                    }
                    else
                    {
                        for (Client& clName : clients)
                        {
                            returnMessage += clName.name;
                            returnMessage.push_back(',');
                        }
                    }
                }
                else if (message.substr(0, 7) == "$getlog")
                {
                    //Do this after the logging has been done
                }
                else if (message.substr(0, 5) == "$exit")
                {
                    client.registered = false;
                    numRegistered--;
                    availableID[client.id] = true;

                    string buff;
                    buff += SV_REMOVE;
                    buff += client.id;
                    int len = buff.size();

                    //send over sv_remove
                    for (Client& node : clients)
                    { 
                        if (node.registered)
                        {
                            //Sending it like this because this is easier than sendMessage rn
                            sendMessage(node.socket, (const char*)&len, 2);
                            sendMessage(node.socket, buffer, len);
                        }
                    }

                    //Remove it from the list of clients
                    for (size_t i = 0; i < clients.size(); i++)
                    {
                        if (clients[i] == client)
                        {
                            clients.erase(clients.begin() + i);
                            break;
                        }
                    }
                }
                else
                {
                    //Any command that isn't listed will send this message back to the client
                    returnMessage += "ERROR: Invalid Command";
                }

                if (returnMessage.size() > 0)
                {
                    int len = returnMessage.size();

                    sendMessage(client.socket, (const char*)&len, 2);
                    sendMessage(client.socket, returnMessage.c_str(), len);
                }
            }
            //All the other messages, pass it on to the clients to display
            else
            {
                for (Client& cli : clients)
                {
                    if (cli.registered)
                    {
                        printf("Received '%d' from Client %d", message, client.name);
                        message = client.name + ": " + message;
                        int len = message.size();
                        sendMessage(cli.socket, (const char*)&len, 2);
                        sendMessage(cli.socket, message.c_str(), length);
                    }
                }
            }


        }


    }

    //Handle the client messages
    for (Client& client : clients)
    {
        if (FD_ISSET(client.socket, &readSet))
        {
            int length = 0;
            int bytesReceived = recMessage(client.socket, (char*)&length, 2, 0);
        }
    }

    return false;
}

//int ChatServer::setsockopt(int sockfd, int level, int optname, const void* optval, socklen_t optlen)
//{
//    return 0;
//}
