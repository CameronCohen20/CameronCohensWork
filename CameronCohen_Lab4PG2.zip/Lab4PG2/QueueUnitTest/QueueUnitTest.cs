using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab4PG2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueueUnitTest
{
    [TestClass()]
    public class PG2QueueTests
    {
        [TestMethod]
        public void TestMethod1()
        {
            PG2Queue<int> queue = new PG2Queue<int>();
            queue.Enqueue(6);
            Assert.AreEqual(1, queue.Count);
            Assert.AreEqual(6, queue.Peek());
            Assert.AreEqual(6, queue.Dequeue());
            Assert.AreEqual(0, queue.Count);
        }

        [TestMethod()]
        public void ReverseTest()
        {
            PG2Queue<int> que = new PG2Queue<int>();
            que.Enqueue(0);
            que.Enqueue(1);
            que.Enqueue(2);
            que.Enqueue(3);
            Assert.AreEqual("4508", que.Print());
            que.Reverse();
            Assert.AreEqual("6084", que.Print());
            que.Reverse();
            Assert.AreEqual("8054", que.Print());
        }
    }
}
