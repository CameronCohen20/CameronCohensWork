using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Pipes;
using FullSailAFI.GamePlaying.CoreAI;

namespace FullSailAFI.GamePlaying
{
    public class StudentAI : Behavior
    {
        TreeVisLib treeVisLib;  // lib functions to communicate with TreeVisualization
        bool visualizationFlag = false;  // turn this on to use tree visualization (which you will have to implement via the TreeVisLib API)
                                         // WARNING: Will hang program if the TreeVisualization project is not loaded!

        public StudentAI()
        {
            if (visualizationFlag == true)
            {
                if (treeVisLib == null)  // should always be null, but just in case
                    treeVisLib = TreeVisLib.getTreeVisLib();  // WARNING: Creation of this object will hang if the TreeVisualization project is not loaded!
            }
        }

        //
        // This function starts the look ahead process to find the best move
        // for this player color.
        //
        public ComputerMove Run(int _nextColor, Board _board, int _lookAheadDepth)
        {
            ComputerMove nextMove = GetBestMove(_nextColor, _board, _lookAheadDepth);

            return nextMove;
        }

        //
        // This function uses look ahead to evaluate all valid moves for a
        // given player color and returns the best move it can find. This
        // method will only be called if there is at least one valid move
        // for the player of the designated color.
        //
        private ComputerMove GetBestMove(int color, Board board, int depth)
        {
            //TODO: the lab


            //Best Move
            ComputerMove bestMove = null;

            List<ComputerMove> validMoves = FindValidMoves(color, board);

            foreach (ComputerMove move in validMoves)
            {
                //new move and board
                Board scratchBoard = new Board();

                scratchBoard.Copy(board);

                scratchBoard.MakeMove(color, move.row, move.col);

                
                if (scratchBoard.IsTerminalState() || depth == 0 || !scratchBoard.HasAnyValidMove(GetOppositePlayer(color)))
                {
                    move.rank = Evaluate(scratchBoard);
                }
                else
                {
                    move.rank = GetBestMove(GetOppositePlayer(color), scratchBoard, depth - 1).rank;
                }
                
                //Sets the new best move
                if (bestMove == null || (move.rank < bestMove.rank && color == Board.Black) || (move.rank > bestMove.rank && color == Board.White))
                {
                    bestMove = move;
                }
            }

            return bestMove;
        }
        #region Recommended Helper Functions


        private int GetOppositePlayer(int color)
        {
            if (color == Board.Black)
            {
                return Board.White;
            }

            return Board.Black;
        }

        private List<ComputerMove> FindValidMoves(int color, Board board)
        {
            List<ComputerMove> validMoves = new List<ComputerMove>();

            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    if (board.IsValidMove(color, row, col))
                    {
                        validMoves.Add(new ComputerMove(row, col));
                    }
                }
            }

            return validMoves;
        }

        

        private int Evaluate(Board _board)
        {
            int score = 0;

            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    int toAdd;

                    if (_board.GetSquareContents(row, col) != Board.Empty)
                    {
                        toAdd = _board.GetSquareContents(row, col);
                    }
                    else
                    {
                        continue;
                    }

                    if ((row == 0 && col == 0) || (row == 7 && col == 0) || (row == 0 || col == 7) || (row == 7 && col == 7))
                    {
                        toAdd *= 99;
                    }
                    else if (row == 0 || row == 7 || col == 0 || col == 7)
                    {
                        toAdd *= 8;
                    }
                    score += toAdd;
                }
            }

            //if it ends the game it adds more to the value
            if (_board.IsTerminalState())
            {
                score += (score > 0) ? 10000 : -10000;
            }
            return score;
        }

        #endregion

    }
}
