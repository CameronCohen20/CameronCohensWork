﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab1BCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1BCL.Tests
{
    [TestClass()]
    public class DealershipTests
    {
        [TestMethod()]
        public void AddCarTest()
        {
            IVehicle car = new Truck(1988,"Ford", "Truck", 4, 1500);
            Dealership carinfo = new Dealership();
            carinfo.AddCar(car);
            Assert.AreEqual(1988, carinfo.inventory[0].Year);
            Assert.AreEqual("Ford", carinfo.inventory[0].Make);
            Assert.AreEqual("Truck", carinfo.inventory[0].Model);
            Assert.AreEqual(4, carinfo.inventory[0].Passengers); 
            
        }
        [TestMethod()]
        public void TestMinivan()
        {
            Minivan car = new Minivan(1987, "Voltwagon", "Minivan", 5, 2);
            Dealership carinfo = new Dealership();
            Assert.AreEqual(1988, carinfo.inventory[0].Year);
            Assert.AreEqual("Ford", carinfo.inventory[0].Make);
            Assert.AreEqual("Truck", carinfo.inventory[0].Model);
            Assert.AreEqual(4, carinfo.inventory[0].Passengers);
        }

    }
}