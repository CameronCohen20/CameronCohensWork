#pragma once
#include "Defines.h"
#include <cmath>
#include "Math.h"
#include "Shaders.h"

unsigned int Raster[_totalPixels] = { 0, };
float ZBuffer[_totalPixels] = { 0, };

unsigned int ConvDim(unsigned int x, unsigned int y, unsigned int width);

void PlotPixel(unsigned int positionX, unsigned int positionY, float z, unsigned int color);



unsigned int Lerp(unsigned int sValue, unsigned int dValue);

unsigned int FloatLerp(float a, float b, float r);

/*void ParametricLine(unsigned int startX, unsigned int startY, unsigned int endX, unsigned int endY); */ //long version that doesnt use any vertex

void ParametricLine(VERTEX sVert, VERTEX eVert);

float ImplicitLineEquation(VERTEX aPos, VERTEX bPos, VERTEX gPos);

void TriangleFill(VERTEX a, VERTEX b, VERTEX c);

BARRYCOORD Barycentric(VERTEX a, VERTEX b, VERTEX c, VERTEX r);



unsigned int ConvDim(unsigned int x, unsigned int y, unsigned int width) {
	return y * width + x;
}

void PlotPixel(unsigned int positionX, unsigned int positionY, float z, unsigned int color) {
	unsigned int position = ConvDim(positionX, positionY, _width);


	if (ZBuffer[position] <= z)
	{
		return;
	}
	ZBuffer[position] = z;
	if (Raster[position] != color && color != 0) //to see if the position doesnt have a color or a color
	{
		Raster[position] = color;
		//unsigned int byte1 = 0xFF000000 & Raster[position]; //white and where the position is

		//if (color < 0xFF000000 && color > 0 && byte1 > 0)
		//{
		//	Raster[position] = (Lerp(Raster[position], color)); //Lerps the current position and makes it the color
		//}
		//else
		//{
		//	Raster[position] = color; //makes the current position the color
		//}
	}
	
}

unsigned int Lerp(unsigned int sValue, unsigned int dValue) {
	unsigned int source[] = { 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF }; //source value with red, green, blue, and aplha
	unsigned int destination[] = { 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF }; //destination value with red, green, blue, and alpha

	for (size_t i = 0; i < 4; i++)
	{
		source[i] = source[i] & sValue;

		destination[i] = destination[i] & dValue;
	}

	int rValue = source[0];
	unsigned int color = 0x00000000;

	for (size_t i = 0; i < 4; i++)
	{
		color += (destination[i] - source[i]) * rValue / 0xFF000000 + source[i]; //(B - A) * R / (derived from alpha) + A
	}

	return color;
}

unsigned int FloatLerp(float a, float b, float r) {
	return (b - a) * r + a;
}

//void ParametricLine(unsigned int startX, unsigned int startY, unsigned int endX, unsigned int endY) {
//	float deltaX = 0;
//	float deltaY = 0;
//
//	deltaX = float(startX) - float(endX);
//	deltaY = float(startY) - float(endY);
//
//	unsigned int color = 0x00FF0000; //green
//
//	if (deltaX != 0 || deltaY != 0)
//	{
//		if (abs(deltaX) >= abs(deltaY))
//		{
//			float currY = float(startY);
//
//			for (unsigned int i = startX; i <= endX; i++)
//			{
//				float r = (i - startX) / deltaX;
//
//				currY = FloatLerp(float(startY), float(endY), abs(r));
//
//				PlotPixel(i, unsigned int(floor(currY + .5f)),  color);
//			}
//		}
//		else
//		{
//			float currX = float(startX);
//
//			for (unsigned int i = startY; i <= endY; i++)
//			{
//				float r2 = (i - startY) / deltaY;
//
//				currX = FloatLerp(float(startX), float(endX), abs(r2));
//
//				PlotPixel(unsigned int(floor(currX + .5f)), i, color);
//			}
//		}
//
//	}
//	else
//	{
//
//		if (deltaX == 0)
//		{
//			for (unsigned int i = startY; i <= endY; i++)
//			{
//				PlotPixel(startX, i, color);
//			}
//		}
//		else if (deltaY == 0)
//		{
//			for (unsigned int i = startX; i <= endX; i++)
//			{
//				PlotPixel(i, startY, color);
//			}
//		}
//	}
//}

inline void ParametricLine(VERTEX sVert, VERTEX eVert)
{
	VERTEX vertStart = sVert;
	VERTEX vertEnd = eVert;


	if (VertexShader)
	{
		VertexShader(vertStart);
		VertexShader(vertEnd);
	}

	VERTEX aPos = NDCtoScreen(vertStart);
	VERTEX bPos = NDCtoScreen(vertEnd);

	float deltaX = fabsf(bPos.position[0] - aPos.position[0]);
	float deltaY = fabsf(bPos.position[1] - aPos.position[1]);

	unsigned int pixels = fmaxf(deltaX, deltaY);
	for (size_t i = 0; i < pixels; i++)
	{
		float r = i / static_cast<float>(pixels); //convert to float

		float x = (bPos.position[0] - aPos.position[0]) * r + aPos.position[0];

		float y = (bPos.position[1] - aPos.position[1]) * r + aPos.position[1];

		float z = (bPos.position[2] - aPos.position[2]) * r + aPos.position[2];

		PlotPixel(x + .5f, y + .5f, z / FARPLANE, aPos.color);
	}
}

inline float ImplicitLineEquation(VERTEX aPos, VERTEX bPos, VERTEX gPos)
{
	return (aPos.position[1] - bPos.position[1]) * gPos.position[0] + (bPos.position[0] - aPos.position[0]) * gPos.position[0] + aPos.position[0] * bPos.position[1] - aPos.position[1] * bPos.position[0];
}

inline void TriangleFill(VERTEX x, VERTEX y, VERTEX z)
{
	VERTEX aCopy = x;
	VERTEX bCopy = y;
	VERTEX cCopy = z;

	if (VertexShader)
	{
		VertexShader(aCopy);
		VertexShader(bCopy);
		VertexShader(cCopy);
	}

	VERTEX a = NDCtoScreen(aCopy);
	VERTEX b = NDCtoScreen(bCopy);
	VERTEX c = NDCtoScreen(cCopy);
	


	int StartX = static_cast<int>(fminf(a.position[0], b.position[0]));
	StartX = static_cast<int>(fminf(StartX, c.position[0]));
	int StartY = static_cast<int>(fminf(a.position[1], b.position[1]));
	StartY = static_cast<int>(fminf(StartY, c.position[1]));

	int EndX = static_cast<int>(fmaxf(a.position[0], b.position[0]));
	EndX = static_cast<int>(fmaxf(EndX, c.position[0]));
	int EndY = static_cast<int>(fmaxf(a.position[1], b.position[1]));
	EndY = static_cast<int>(fmaxf(EndY, c.position[1]));

	unsigned int color = a.color;
	for (int i = StartY;  i <  EndY; i++)
	{
		for (int j = StartX; j < EndX; j++)
		{
			VERTEX r = { { static_cast<float>(j), static_cast<float>(i),0,0 }, 0xFF000000 };
			auto barycentric = Barycentric(a, b, c, r);

			if (barycentric.x >= 0 && barycentric.x <= 1 && barycentric.y >= 0 && barycentric.y <= 1 && barycentric.z >= 0 && barycentric.z <= 1) {
				float z = Berp(a.position[2], b.position[2], c.position[2], barycentric) / FARPLANE;

				color = BerpColor({ a.color, b.color, c.color }, barycentric);

				PlotPixel(j, i, z, color);
			}
		}
	}

}

//inline void TriangleFill(VERTEX x, VERTEX y, VERTEX z)
//{
//	VERTEX copy_a = x;
//	VERTEX copy_b = y;
//	VERTEX copy_c = z;
//
//	if (VertexShader)
//	{
//		VertexShader(copy_a);
//		VertexShader(copy_b);
//		VertexShader(copy_c);
//	}
//
//	VERTEX a = NDCtoScreen(copy_a);
//	VERTEX b = NDCtoScreen(copy_b);
//	VERTEX c = NDCtoScreen(copy_c);
//
//	int StartX = static_cast<int>(fminf(a.position[0], b.position[0]));
//	StartX = static_cast<int>(fminf(StartX, c.position[0]));
//	int StartY = static_cast<int>(fminf(a.position[1], b.position[1]));
//	StartY = static_cast<int>(fminf(StartY, c.position[1]));
//
//	int EndX = static_cast<int>(fmaxf(a.position[0], b.position[0]));
//	EndX = static_cast<int>(fmaxf(EndX, c.position[0]));
//	int EndY = static_cast<int>(fmaxf(a.position[1], b.position[1]));
//	EndY = static_cast<int>(fmaxf(EndY, c.position[1]));
//
//	unsigned int color = a.color;
//
//	for (int y = StartY; y < EndY; y++)
//	{
//		for (int x = StartX; x < EndX; x++)
//		{
//			VERTEX p = {
//				{static_cast<float>(x),static_cast<float>(y),0,0}, 0xFF000000
//			};
//			auto bary = Barycentric(a, b, c, p);
//			if (bary.x >= 0 && bary.x <= 1 &&
//				bary.y >= 0 && bary.y <= 1 &&
//				bary.z >= 0 && bary.z <= 1)
//			{
//				float z = Berp(a.position[2], b.position[2], c.position[2], bary) / FARPLANE;
//				color = BerpColor({ a.color, b.color, c.color }, bary);
//				PlotPixel(x, y, z, color);
//			}
//		}
//	}
//}

inline BARRYCOORD Barycentric(VERTEX a, VERTEX b, VERTEX c, VERTEX r)
{
	float maxA = ImplicitLineEquation(b, c, a);
	float maxB = ImplicitLineEquation(a, c, b);
	float maxC = ImplicitLineEquation(b, a, c);

	float subA = ImplicitLineEquation(b, c, r);
	float subB = ImplicitLineEquation(a, c, r);
	float subC = ImplicitLineEquation(b, a, r);


	return { subA / maxA, subB / maxB, subC / maxC };
}


