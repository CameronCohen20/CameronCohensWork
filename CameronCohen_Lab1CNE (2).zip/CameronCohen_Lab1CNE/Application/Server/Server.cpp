#include "Server.h"

int Server::init(uint16_t port)
{
	
	listSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (listSocket == INVALID_SOCKET) 
	{
		return SETUP_ERROR;
	}

	
	if (listen(listSocket, 1) == SOCKET_ERROR) \
	{
		return SETUP_ERROR;
	}

	
	sockaddr_in serverAddy;

	serverAddy.sin_family = AF_INET;
	serverAddy.sin_addr.S_un.S_addr = INADDR_ANY;
	serverAddy.sin_port = htons(port);

	int result = bind(listSocket, (SOCKADDR*)&serverAddy, sizeof(serverAddy));
	if (result == SOCKET_ERROR) 
	{
		return BIND_ERROR;
	}


	
	cSocket = accept(listSocket, NULL, NULL);
	if (cSocket == INVALID_SOCKET)
	{
		if (WSAGetLastError() == WSAENETDOWN) 
		{
			return SHUTDOWN;
		}
		return CONNECT_ERROR;
	}
	return SUCCESS;
}
int Server::readMessage(char* buffer, int32_t size)
{
	int mSize = 0;
	int temp = recv(cSocket, (char*)&mSize, 1, 0);

	if (temp == SOCKET_ERROR || temp == 0)
	{
		if (WSAGetLastError() == SHUTDOWN) 
		{
			return SHUTDOWN;
		}

		return DISCONNECT;
	}

	int bytes = 0;
	while (bytes < mSize)
	{
		int result = recv(cSocket, buffer + bytes, mSize - bytes, 0);
		if (result == SOCKET_ERROR || result == 0)
		{
			if (WSAGetLastError() == SHUTDOWN) 
			{
				return SHUTDOWN;
			}

			return DISCONNECT;
		}
		else
			bytes += result;
	}

	if (bytes > size) 
	{
		return PARAMETER_ERROR;
	}

	return SUCCESS;
}
int Server::sendMessage(char* data, int32_t length)
{
	int result = 0;
	int bytesGone = 0;
	
	result = send(cSocket, (const char*)&length, 1, 0);

	if (result <= 0)
	{
		if (WSAGetLastError() == SHUTDOWN) 
		{
			return SHUTDOWN;
		}

		return DISCONNECT;
	}

	while (bytesGone < length)
	{

		result = send(cSocket, (const char*)data + bytesGone, length - bytesGone, 0);

		if (result <= 0)
		{
			if (WSAGetLastError() == SHUTDOWN) 
			{
				return SHUTDOWN;
			}
			return DISCONNECT;
		}
		bytesGone += result;
	}

	if (length < 0 || length > 255) 
	{
		return PARAMETER_ERROR;
	}

	return SUCCESS;
}
void Server::stop()
{
	shutdown(listSocket, SD_BOTH);
	closesocket(listSocket);

	shutdown(cSocket, SD_BOTH);
	closesocket(cSocket);
}