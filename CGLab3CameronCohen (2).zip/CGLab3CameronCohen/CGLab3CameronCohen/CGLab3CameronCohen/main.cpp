#include "RasterSurface.h"
#include "Defines.h"
#include "ScreenDraw.h"
#include <cmath>
#include "Shaders.h"
#include <algorithm>
const char* _cameronCohen;



int main() {
	std::fill_n(ZBuffer, _totalPixels, 1); //fills entire array with the value of 1
	MATRIX worldMatrix;
	MATRIX cameraMatrix;
	MATRIX projectionMatrix;
	MATRIX idMatrix;
	MATRIX cubeMatrix;


	//projection
	projectionMatrix.matrix[1][1] = cosf(.5f * FOV) / sinf(.5f * FOV);

	projectionMatrix.matrix[0][0] = projectionMatrix.matrix[1][1] * ASPECTRATIO;

	projectionMatrix.matrix[2][2] = FARPLANE / (FARPLANE - NEARPLANE);

	projectionMatrix.matrix[2][3] = 1;

	projectionMatrix.matrix[3][2] = -(FARPLANE * NEARPLANE) / (FARPLANE - NEARPLANE);

	//sets the view(camera) matrix to a perspective 
	cameraMatrix = BuildRotationMatrixX(-18.0f * PI / 180.0f);
	cameraMatrix.matrix[3][2] = -1;

	VertexShader = VS_3DPipeLine;
	SV_CameraMatrix = cameraMatrix;
	SV_ProjectionMatrix = projectionMatrix;

	// Setting each to the identity matrix
	for (size_t i = 0; i < 4; i++)
	{
		for (size_t j = 0; j < 4; j++)
		{
			if (i - j == 0)
			{
				worldMatrix.matrix[i][j] = 1.0f;

				idMatrix.matrix[i][j] = 1.0f;
			}
		}
	}
	//sets cube matrix as id matrix
	cubeMatrix = idMatrix;

	cubeMatrix.matrix[3][1] = .25f;



	RS_Initialize(_cameronCohen, _width, _height);
	//4 grid points
	VERTEX gridTop[11];
	VERTEX gridLeft[11];
	VERTEX gridRight[11];
	VERTEX gridBott[11];


	////each point on the cube
	//VERTEX cube[8] = {
	//	{ {-0.25f, 0.25f, -0.25f, 1}, 0xFF00FF00 },
	//	{ {0.25f, 0.25f, -0.25f, 1}, 0xFFFF0000 },
	//	{ {0.25f, -0.25f, -0.25f, 1}, 0xFF0000FF},
	//	{ {-0.25f, -0.25f, -0.25f, 1}, 0xFFFFFF00 },
	//	{ {-0.25f, 0.25f, 0.25f, 1}, 0xFF00FFFF },
	//	{ {0.25f, 0.25f, 0.25f, 1}, 0xFFFF00FF },
	//	{ {0.25f, -0.25f, 0.25f, 1}, 0xFF00FF00 },
	//	{ {-0.25f, -0.25f, 0.25f, 1}, 0xFFFFFF00 }
	//};

	VERTEX cube[24] = {
		//face 1
		{ {-0.25f, 0.25f, -0.25f, 1}, 0xFF00FF00 },
		{ {0.25f, 0.25f, -0.25f, 1}, 0xFFFF0000 },
		{ {0.25f, -0.25f, -0.25f, 1}, 0xFF0000FF },
		{ {-0.25f, -0.25f, -0.25f, 1}, 0xFFFFFF00 },
		//face 2
		{ {-0.25f, 0.25f, 0.25f, 1}, 0xFF00FFFF },
		{ {0.25f, 0.25f, 0.25f, 1}, 0xFFFF00FF },
		{ {0.25f, -0.25f, 0.25f, 1}, 0xFF0FFFFF },
		{ {-0.25f, -0.25f, 0.25f, 1}, 0xFFFFFFF0 },
		//face 3
		{ {0.25f, 0.25f, -0.25f, 1}, 0xFF00FF00 },
		{ {0.25f, 0.25f, 0.25f, 1}, 0xFFFF0000 },
		{ {0.25f, -0.25f, 0.25f, 1}, 0xFF0000FF },
		{ {0.25f, -0.25f, -0.25f, 1}, 0xFFFFFF00 },
		//face 4
		{ {-0.25f, 0.25f, 0.25f, 1}, 0xFF00FF00 },
		{ {-0.25f, 0.25f, -0.25f, 1}, 0xFFFF0000 },
		{ {-0.25f, -0.25f, -0.25f, 1}, 0xFF0000FF },
		{ {-0.25f, -0.25f, 0.25f, 1}, 0xFFFFFF00 },
		//face 5
		{ {-0.25f, 0.25f, 0.25f, 1}, 0xFF00FF00 },
		{ {0.25f, 0.25f, 0.25f, 1}, 0xFFFF0000 },
		{ {0.25f, 0.25f, -0.25f, 1}, 0xFF0000FF },
		{ {-0.25f, 0.25f, -0.25f, 1}, 0xFFFFFF00 },
		//face 6
		{ {-0.25f, -0.25f, -0.25f, 1}, 0xFF00FF00 },
		{ {0.25f, -0.25f, -0.25f, 1}, 0xFFFF0000 },
		{ {0.25f, -0.25f, 0.25f, 1}, 0xFF0000FF },
		{ {-0.25f, -0.25f, 0.25f, 1}, 0xFFFFFF00 }
	}; 


	//grid positions
	for (size_t i = 0; i < 11; i++)
	{
		gridTop[i].position[2] = .5f;
		gridLeft[i].position[0] = -.5f;
		gridRight[i].position[0] = .5f;
		gridBott[i].position[2] = -.5f;

		gridTop[i].position[0] = -.5f + (i * .1f);
		gridLeft[i].position[2] = .5f - (i * .1f);
		gridRight[i].position[2] = .5f - (i * .1f);
		gridBott[i].position[0] = -.5f + (i * .1f);
	}

	while (RS_Update(Raster, _totalPixels))
	{
		//clears the raster to black before things getting drawn
	/*	for (size_t i = 0; i < _totalPixels; i++)
		{
			Raster[i] = 0;

		}*/
		std::fill_n(Raster, _totalPixels, 0);
		std::fill_n(ZBuffer, _totalPixels, 1);

		//grid being drawn
		SV_WorldMatrix = idMatrix;
		for (size_t i = 0; i < 11; i++)
		{
			ParametricLine(gridTop[i], gridBott[i]);
			ParametricLine(gridLeft[i], gridRight[i]);
		}


		//Rotating the cube
		cubeMatrix = MultiplyMatrixByMatrix(BuildRotationMatrixY(1.0f * PI / 1800), cubeMatrix);

		//sets the world matrix to the cube matrix
		SV_WorldMatrix = cubeMatrix;

		/*for (size_t i = 0; i < 24; i += 4)
		{
			TriangleFill(cube[i], cube[i + 1], cube[i + 2]);
			TriangleFill(cube[i], cube[i + 3], cube[i + 2]);

		}*/

		TriangleFill(cube[0], cube[1], cube[2]);
		for (size_t i = 0; i < 8; i++)
		{
			if (i == 3)
				ParametricLine(cube[i], cube[0]);
			else if (i == 7)
				ParametricLine(cube[i], cube[4]);
			else
				ParametricLine(cube[i], cube[i + 1]);
		}
		for (int i = 0; i < 4; i++)
			ParametricLine(cube[i], cube[i + 4]);

		//drawing the cube
		/*ParametricLine(cube[0], cube[1]);
		ParametricLine(cube[0], cube[3]);
		ParametricLine(cube[0], cube[4]);
		ParametricLine(cube[6], cube[5]);
		ParametricLine(cube[6], cube[2]);
		ParametricLine(cube[6], cube[7]);
		ParametricLine(cube[4], cube[5]);
		ParametricLine(cube[1], cube[5]);
		ParametricLine(cube[4], cube[7]);
		ParametricLine(cube[3], cube[7]);
		ParametricLine(cube[3], cube[2]);
		ParametricLine(cube[1], cube[2]);*/


	}


	RS_Shutdown();
}