﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace GOLStartUpTemplate1
{
    public partial class Size : Form
    {
        public Size()
        {
            InitializeComponent();
        }

        public int HeightM
        {
            get
            {
                return (int)Height.Value;
            }
            set
            {
                Height.Value = value;
            }

        }

        public int WidthM
        {
            get
            {
                return (int)Width.Value;
            }
            set
            {
                Width.Value = value;
            }
        }

        private void Size_Load(object sender, EventArgs e)
        {
            
        }
    }
}
