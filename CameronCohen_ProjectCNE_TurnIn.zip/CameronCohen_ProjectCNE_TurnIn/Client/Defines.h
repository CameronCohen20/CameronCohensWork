#pragma once
#include <WinSock2.h>
#include <stdint.h>

//Receives message being sent to the socket and outputs it to buffer
int recMessage(SOCKET s, char* buffer, int len, int flags);

//Sends data to given socket 
int sendMessage(SOCKET s, const char* data, int length);

enum NET_MESSAGE_TYPE
{
	SV_FULL,
	SV_SUCCESS,
	SV_EMPTY,
	SV_REMOVE,
	SV_ADD
};