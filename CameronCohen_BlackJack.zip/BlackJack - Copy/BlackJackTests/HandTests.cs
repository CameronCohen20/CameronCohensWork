﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BlackJack;
using Main_Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BlackJack.Tests
{
    [TestClass()]
    public class HandTests
    {
        [TestMethod()]
        public void AddCardTest()
        {
            Cards aceOfSpades = new Cards("Ace", "Spades");
            Cards ten = new Cards("ten", "Spades");
            Cards eight = new Cards("eight", "Hearts");
            Hand testHand = new Hand();

            testHand.AddCard(aceOfSpades);
            testHand.AddCard(eight);
            Assert.AreEqual(21, testHand.Score);
            testHand.AddCard(ten);
            Assert.AreEqual(21, testHand.Score);
        }
    }
}