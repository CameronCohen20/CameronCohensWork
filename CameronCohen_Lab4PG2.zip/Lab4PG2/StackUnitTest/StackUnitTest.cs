using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab4PG2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace StackUnitTest
{
    [TestClass()]
    public class PG2StackTests
    {
        [TestMethod()]
        public void TestMethod1()
        {
            PG2Stack<int> stack = new PG2Stack<int>();
            stack.Push(1);
            Assert.AreEqual(1, stack.Count);
            Assert.AreEqual(1, stack.Peek());
            Assert.AreEqual(1, stack.Pop());
            Assert.AreEqual(0, stack.Count);
        }

        [TestMethod()]
        public void ReverseTest()
        {
            PG2Stack<int> stack = new PG2Stack<int>();
            stack.Push(0);
            stack.Push(1);
            stack.Push(2);
            stack.Push(3);
            Assert.AreEqual("4508", stack.Print());
            stack.Reverse();
            Assert.AreEqual("6084", stack.Print());
            stack.Reverse();
            Assert.AreEqual("8054", stack.Print());
        }

    }
}
