#pragma once
#include <vector>
#include <WinSock2.h>
#include <stdint.h>
#include <string>
#include "../Client/Defines.h"

using namespace std;


class ChatServer
{
	//Custom Client struct to keep track of connections
	struct Client
	{
		bool registered = false;
		SOCKET socket;
		int id = -1;
		string name;

		Client(SOCKET _socket)
		{
			registered = false;
			id = -1;
			socket = _socket;
		}

		//Does a full comparison between different clients
		bool operator==(Client other)
		{
			return (socket == other.socket) && (id == other.id) && (name == other.name);
		}
	};

	SOCKET listenSocket;

	vector<Client> clients;

	bool availableID[4];
	int numRegistered;

	fd_set masterSet;

public:

	//Cleanup any connections/tell clients to stop
	~ChatServer();

	//Establishes listening socket
	bool init(uint16_t port);

	//The main loop
	bool run();

};

