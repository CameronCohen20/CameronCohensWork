﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    public class Deck
    {
        public List<Cards> Card { get; set; }

        public Deck()
        {
            this.Card = new List<Cards> {};

            foreach (string value1 in Cards.ValidValue())
            {
                foreach (string suit1 in Cards.ValidSuit())
                {
                    this.Card.Add(new Cards(value1, suit1));
                }
            }

        }

        public Cards DrawCard()
        {
            Cards drawCard = Card[0];
            Card.RemoveAt(0);
            return drawCard;
        }

        public void Shuffle()
        {
            List<Cards> temp = new List<Cards> { };
            Random rando = new Random();
            int count = Card.Count;
            while (temp.Count < count)
            {
                int num = rando.Next(Card.Count);
                temp.Add(Card[num]);
                Card.RemoveAt(num);
            }
            Card = temp;
        }

        public void ShowDeck()
        {
            for (int i = 0; i < Card.Count; i++)
            {
                Card[i].Display();
                Console.WriteLine();
            }
        }
    }


}
