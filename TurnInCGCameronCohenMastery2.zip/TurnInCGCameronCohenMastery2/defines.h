#pragma once

#define _WIDTH 500
#define _HEIGHT 500
#define _TOTALPIXELS (_WIDTH * _HEIGHT)
#define PI 3.14159

struct VERTEX { float position[4]; unsigned int color; };

struct MATRIX { float matrix[3][3]; };

struct VER_3D { float x, y, z; };

struct VER_2D { float x, y; };

struct COLOR { unsigned int x, y, z; };

typedef VER_3D BARYCOORD;