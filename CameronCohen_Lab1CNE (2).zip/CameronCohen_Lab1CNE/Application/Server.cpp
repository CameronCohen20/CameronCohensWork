#include "Server.h"

int Server::init(uint16_t port)
{
	server_Listen_Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (server_Listen_Socket == INVALID_SOCKET)
	{
		//DEBUG: Socket Incorrect
		int error = WSAGetLastError();
		return SETUP_ERROR;
	}
	//DEBUG: Socket Setup

	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.S_un.S_addr = INADDR_ANY;
	serverAddr.sin_port = htons(31337);

	int result = bind(server_Listen_Socket, (SOCKADDR*)&serverAddr, sizeof(serverAddr));
	if (result == SOCKET_ERROR)
	{
		//DEBUG: Bind Incorrect
		int error = WSAGetLastError();
		return BIND_ERROR;
	}
	//DEBUG: Bind Correct

	result = listen(server_Listen_Socket, 1);
	if (result == SOCKET_ERROR)
	{
		//DEBUG: Listen Incorrect
		int error = WSAGetLastError();
		return SETUP_ERROR;
	}
	//DEBUG: Listen Correct

	server_Comm_Socket = accept(server_Listen_Socket, NULL, NULL);
	if (server_Comm_Socket == INVALID_SOCKET)
	{
		//DEBUG: Accept Incorrect
		int error = WSAGetLastError();
		return CONNECT_ERROR;
	}
	else if (server_Comm_Socket == SOCKET_ERROR)
	{
		int error = WSAGetLastError();
		return SHUTDOWN;
	}
	
	return SUCCESS;
}
int Server::readMessage(char* buffer, int32_t size)
{
	uint8_t bufferSize = size;
	int size_result = receiveTcpData(server_Comm_Socket, (char*)&bufferSize, 1);
	if ((size_result == SOCKET_ERROR))
	{
		int error = WSAGetLastError();
		//DEBUG: Read Is Incorrect
		return MESSAGE_ERROR;
	}
	else if (size_result == 0)
	{
		return SHUTDOWN;
	}

	if (size < checkBufferSize(buffer) || size <= 0)
	{
		//DEBUG: Message Size Error
		int error = WSAGetLastError();
		return PARAMETER_ERROR;
	}
	//DEBUG: Message Size Valid

	int result = receiveTcpData(server_Comm_Socket, buffer, bufferSize);
	if ((result == INVALID_SOCKET))
	{
		int error = WSAGetLastError();
		//DEBUG: Read Is Incorrect
		return CONNECT_ERROR;
	}
	else if (result == 0)
	{
		return SHUTDOWN;
	}
		
	return SUCCESS;
}
int Server::sendMessage(char* data, int32_t length)
{
	uint8_t message_size = length;
	int size_result = sendTcpData(server_Comm_Socket, (char*)&message_size, 1);
	if (size_result == SOCKET_ERROR)
	{
		//Debug: Send is incorrect
		int error = WSAGetLastError();
		return MESSAGE_ERROR;
	}
	else if (size_result == INVALID_SOCKET)
	{
		return SHUTDOWN;
	}

	if (length == 0 || length > 255)
	{
		//DEBUG: Message Size Error
		int error = WSAGetLastError();
		return PARAMETER_ERROR;
	}
	//DEBUG: Message Size Valid

	int message_result = sendTcpData(server_Comm_Socket, data, length);
	if (message_result == SOCKET_ERROR)
	{
		//Debug: Send is incorrect
		int error = WSAGetLastError();
		return MESSAGE_ERROR;
	}
	else if (message_result == INVALID_SOCKET)
	{
		return SHUTDOWN;
	}
		
	// Debug: Message Sent
	return SUCCESS;	
}
void Server::stop()
{
	shutdown(server_Listen_Socket, SD_BOTH);
	closesocket(server_Listen_Socket);

	shutdown(server_Comm_Socket, SD_BOTH);
	closesocket(server_Comm_Socket);
}