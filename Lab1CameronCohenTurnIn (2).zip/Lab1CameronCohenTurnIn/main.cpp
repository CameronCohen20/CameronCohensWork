#include "RasterSurface.h"
#include "tiles_12.h"
#include "XTime.h"
#include <time.h>
#include "fire_01c.h"

#define _width  500 //width of screen
#define _height  500 //height of screen
#define _totalPixels  (_width * _height) //the height and width of the screen summed togther
unsigned int Raster[_totalPixels] = { 0, }; //holds the total amount of pixels in an array

const char* _cameronCohen;

void ClearColor(unsigned int color);
unsigned int ConvDim(unsigned int x, unsigned int y, unsigned int width);
void PlotPixel(unsigned int position, unsigned int color);
unsigned int Lerp(unsigned int sValue, unsigned int eValue);
void BLIT(const unsigned int source[], unsigned int sourceWidth, unsigned int sourceHeight, unsigned int sourceX, unsigned int sourceY, unsigned int destinationX, unsigned int destinationY, unsigned int width, unsigned int height);
unsigned int ColorConv(unsigned int argb);

int main() {
	RS_Initialize(_cameronCohen, _width, _height); //creates the window

	//random image before while
	srand(time(NULL));
	unsigned int x;
	unsigned int y;



	unsigned int fireX = 0;
	unsigned int fireY = 0;

	int pngX[10] = { 0, };
	int pngY[10] = { 0, };

	for (size_t i = 0; i < 10; i++)
	{
		pngX[i] = rand() % _width;
		pngY[i] = rand() % _height;
	}

	while (RS_Update(Raster, _totalPixels)) {
		//Tiles for Background
		for (size_t i = 0; i <= _height / 32; i++)
		{
			for (size_t j = 0; j <= _width / 32; j++)
			{
				BLIT(tiles_12_pixels, 400, 224, 288, 128, 32 * i, 32 * j, 32, 32);

			}
		}

		for (size_t i = 0; i < 10; i++) //10 images on screen
		{
			

			BLIT(tiles_12_pixels, 400, 224, 16, 16, pngX[i], pngY[i], 96, 84);
		}
		
		/*BLIT(tiles_12_pixels, 400, 224, 16, 16, 112, 100, 96, 84);*/
		BLIT(fire_01c_pixels, fire_01c_width, fire_01c_height, fireX, fireY, 100, 112, 128, 128);

		fireX = fireX + 128;
		if (fireX >= fire_01c_width)
		{
			fireX = 0;
			fireY = fireY + 128;
			if (fireY >= fire_01c_height)
			{
				fireY = 0;
			}
		}

	}
	


	RS_Shutdown(); //shuts down the program when window is closed
}


void ClearColor(unsigned int color) {

	for (size_t i = 0; i < _totalPixels; i++)
	{
		Raster[i] = color; //turns the pixels into the color
	}
}

unsigned int ConvDim(unsigned int x, unsigned int y, unsigned int width) {

	return y * width + x; 
}


//convertions to hex
//red = 0x00FF0000
//blue = 0x000000FF
//green = 0x0000FF00
//white = 0xFFFFFFFF
//black = 0x00000000


void PlotPixel(unsigned int position, unsigned int color) {
	unsigned int byte = 0xFF000000 & color; //black color for pixel



	if (Raster[position] != color && byte != 0) //to see if the position doesnt have a color or a color
	{
		unsigned int byte1 = 0xFF000000 & Raster[position]; //white and where the position is

		if (byte < 0xFF000000 && byte > 0 && byte1 > 0)
		{
			Raster[position] = (Lerp(Raster[position], color)); //Lerps the current position and makes it the color
		}
		else
		{

			Raster[position] = color; //makes the current position the color
		}
	}
}

unsigned int Lerp(unsigned int sValue, unsigned int dValue) {
	unsigned int source[] = { 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF }; //source value with red, green, blue, and aplha
	unsigned int destination[] = { 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF }; //destination value with red, green, blue, and alpha

	for (size_t i = 0; i < 4; i++)
	{
		source[i] = source[i] & sValue;

		destination[i] = destination[i] & dValue;
	}

	int rValue = source[0];
	unsigned int color = 0x00000000;

	for (size_t i = 0; i < 4; i++)
	{
		color += (destination[i] - source[i]) * rValue / 0xFF000000 + source[i]; //(B - A) * R / (derived from alpha) + A
	}

	return color;
}

void BLIT(const unsigned int source[], unsigned int sourceWidth, unsigned int sourceHeight, unsigned int sourceX, unsigned int sourceY, unsigned int destinationX, unsigned int destinationY, unsigned int width, unsigned int height) {


	unsigned int destPos = ConvDim(destinationX, destinationY, _width); //converts destination to a 1D coord
	unsigned int sourcePos = ConvDim(sourceX, sourceY, sourceWidth); //converts image to a 1D coord
	unsigned int color = 0x00000000;

	for (size_t i = 0; i < height; i++)
	{
		for (size_t l = 0; l < width; l++)
		{
			color = ColorConv(source[sourcePos]); //color variable is now the image being

			PlotPixel(destPos, color);

			destPos++;
			sourcePos++;

			if (destPos % _width == 0)
			{
				break;
			}
		}

		sourcePos = ConvDim(sourceX, sourceY, sourceWidth) + sourceWidth * (i + 1);
		destPos = ConvDim(destinationX, destinationY, _width) + _width * (i + 1);

		if (destPos > _totalPixels)
		{
			break;
		}
	}
}



unsigned int ColorConv(unsigned int argb) {
	unsigned int rByte = 0x0000FF00; //red
	unsigned int gByte = 0x00FF0000; //green
	unsigned int bByte = 0xFF000000; //blue
	unsigned int aByte = 0x000000FF; //alpha

	unsigned int color = 0x00000000;

	rByte = rByte & argb;
	gByte = gByte & argb;
	bByte = bByte & argb;
	aByte = aByte & argb;

	rByte = rByte << 8;
	gByte = gByte >> 8;

	bByte = bByte >> 24;
	aByte = aByte << 24;

	color |= rByte;
	color |= gByte;
	color |= bByte;
	color |= aByte;

	return color;
}