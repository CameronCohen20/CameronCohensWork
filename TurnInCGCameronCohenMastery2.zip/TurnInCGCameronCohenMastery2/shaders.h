#pragma once
#include "defines.h"
#include "math.h"

void (*VertexShader) (VERTEX&) = 0;


MATRIX SV_WORLDMATRIX;

void VS_World(VERTEX& multiplyMe) {
	multiplyMe = MultiplyVerByMatrix(multiplyMe, SV_WORLDMATRIX);
}