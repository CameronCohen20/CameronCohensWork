﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab1BCL;

namespace LabA
{
    class Program
    {
        static void Main(string[] args)
        {
            Dealership carinfo = new Dealership();
            string[] item = new string[] { "1.Add Car", "2.Show Cars", "3.Exit" };
            int menuChoice = 0;
            string menuItem = string.Empty;
            string addMake = string.Empty;
            string addModel = string.Empty;
            ReadString("What is the name of your car dealership?", ref menuItem);
            Console.WriteLine("Welcome to " + menuItem + " Dealership");
           
            bool check = true;
            while (check)
            {
                ReadChoice("You did not make a valid selection.", item, out menuChoice);
                if (menuChoice == 1)
                {
                   
                    string[] cars = new string[] { "1.Minivan", "2.Truck" };
                    ReadChoice("Would you Like to Add a Minivan or Truck?", cars, out int choice);
                    int year = ReadInteger("Year: ", 1908, 2021);
                    ReadString("What is the Make?", ref addMake);
                    ReadString("What is the Model?", ref addModel);
                    int seats = ReadInteger("How many seats?", 1, 8);

                    if (choice == 1)
                    {
                        IVehicle car = Factory.CreateMinivan( year,addMake, addModel, seats, ReadInteger("How many Sliding Doors?", 0, 2));
                        carinfo.AddCar(car);
                    }
                    else if (choice == 2)
                    {
                        IVehicle truck = Factory.CreateTruck( year, addMake, addModel, seats, ReadInteger("How much Capacity?", 1000, 15000));
                        carinfo.AddCar(truck);
                    }
                   

                    Console.WriteLine("Press any key to continue.");
                }
                else if (menuChoice == 2)
                {
                    carinfo.Display();
                    Console.WriteLine("You selected Show Cars.");
                    Console.WriteLine("Press any key to continue.");
                }
                else if (menuChoice == 3)
                {
                    Console.WriteLine("You selected Exit.");
                    check = false;
                }
                else
                {
                    Console.WriteLine("You did not make a valid selection.");
                    Console.WriteLine("Press any key to continue.");

                }
                Console.ReadKey();
                Console.Clear();
            }
        }

        
        static int ReadInteger(string Integer)
        {
            int x = 0;
            
            while (true)
            {
                Console.WriteLine(Integer);
                if (Int32.TryParse(Console.ReadLine(), out x))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error!! Please try again to enter an Integer.");
                }
            }

            return x;
        }

        static int ReadInteger(string Integer, int min, int max)
        {
            int x = 0;
            while (true)
            {
                Console.WriteLine(Integer);
                if (Int32.TryParse(Console.ReadLine(), out x) || (x >= min && x <= max))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error!! Please try again to enter an Integer.");
                }
            }

            return x;
        }

        static void ReadString(string String,ref string y)
        {
            Console.WriteLine(String);
            while (true)
            {
                y = Console.ReadLine();
                if (y == "")
                {
                   Console.WriteLine("Error!! Please try again to enter an String.");
                }
                else
                {
                    break;
                }

            }

        }
        static void ReadChoice(string prompt, string[] options, out int selection)
        {
            foreach (string x in options)
            {
                Console.WriteLine(x);
            }
            selection = ReadInteger("Choice? ");
        }
    }
}
