﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    public class Hand
    {
        public int Score { get; set; }
        private List<Cards> _cards;
        private int NumberOfAces;

        public List<Cards> Cards
        {
            get { return _cards; }
        }

        public Hand()
        {
            _cards = new List<Cards>();
            NumberOfAces = 0;
        }

        public void AddCard(Cards draw)
        {
            _cards.Add(draw);
            if (int.TryParse(draw.Value, out int score))
            {
               Score += score;
            }
            else if (draw.Value == "Ace")
            {
                NumberOfAces++;
                if (Score >= 11)
                {
                    Score++;
                }
                else
                {
                    Score += 11;
                }
            }
            else
            {
                Score += 10;
            }

            if (Score > 21 && NumberOfAces > 0)
            {
                Score -= 10;
                NumberOfAces--;
            }
          
        }

    }
}
