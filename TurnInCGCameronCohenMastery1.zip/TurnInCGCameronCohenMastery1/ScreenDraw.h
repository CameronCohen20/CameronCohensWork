#pragma once
#include "defines.h"
#include <corecrt_math.h>


unsigned int Raster[_TOTALPIXELS];

unsigned int ConvPos(unsigned int x, unsigned int y, unsigned int width);
void PlotPixel(unsigned int x, unsigned int y, unsigned int _color);
float ImplicitLineEquation(float x, float y, VER_2D a, VER_2D b);
void ParametricLine(VERTEX_2D a, VERTEX_2D b);
void BresenhamLine(VERTEX_2D a, VERTEX_2D b);
void MidPointLine(VERTEX_2D a, VERTEX_2D b);



unsigned int ConvPos(unsigned int x, unsigned int y, unsigned int width) {
	return y * width + x;
}

inline void PlotPixel(unsigned int x, unsigned int y, unsigned int _color)
{
	unsigned int _position = ConvPos(x, y, _WIDTH);

	if (Raster[_position] != _color && _color != 0)
	{
		Raster[_position] = _color;
	}
}

inline float ImplicitLineEquation(float x, float y, VER_2D a, VER_2D b)
{
	return (a.y - b.y) * x + (b.x - a.x) * y + a.x * b.y - a.y * b.x;
}

void ParametricLine(VERTEX_2D a, VERTEX_2D b) {
	float dx = fabsf(b.position.x - a.position.x);
	float dy = fabsf(b.position.y - a.position.y);

	int _totalPixels = static_cast<int>(fmaxf(dx, dy)); //casts the dx and dy to _totalPixels and makes them ints
	unsigned int _color = 0;

	unsigned int aColor[] = { 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF };
	unsigned int bColor[] = { 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF };

	for (size_t i = 0; i < 4; i++)
	{
		aColor[i] = aColor[i] & a.color;
		bColor[i] = bColor[i] & b.color;
	}

	for (size_t i = 0; i < _totalPixels; ++i)
	{
		_color = 0;
		for (size_t j = 0; j < 4; j++)
		{
			_color |= (bColor[j] - aColor[j]) * i / _totalPixels + aColor[j];
		}
		float R = i / static_cast<float>(_totalPixels);
		float x = (b.position.x - a.position.x) * R + a.position.x;
		float y = (b.position.y - a.position.y) * R + a.position.y;


		PlotPixel(static_cast<int>(x + 0.5f), static_cast<int>(y + 0.5f), _color);
	}
}

inline void BresenhamLine(VERTEX_2D a, VERTEX_2D b)
{
	int currentY = a.position.y;
	float slope = (b.position.y - a.position.y) / (b.position.x - a.position.x);
	
	float err = 0;

	for (size_t currentX = a.position.x; currentX <= b.position.x; currentX++)
	{
		PlotPixel(currentX, currentY, 0xFFFF0000);
		err += slope;
		if (err > 0.5)
		{
			currentY += 1;
			err -= 1;
		}
	}
}

inline void MidPointLine(VERTEX_2D a, VERTEX_2D b)
{
	int currentY = a.position.y;
	float midY = 0;
	float midX = 0;

	for (size_t currentX = a.position.x; currentX <= b.position.x; currentX++)
	{
		PlotPixel(currentX, currentY, 0xFF00FF00);
		midX = currentX + 1;
		midY = currentY + 0.5f;

		if (ImplicitLineEquation(midX, midY, a.position, b.position) < 0)
		{
			currentY += 1;
		}
	}
}


	

