#pragma once

// this has windows, vector, etc.
#include "SaiphApp.h"

// Game Headers
#include "Resource.h"
#include "StopWatch.h"

