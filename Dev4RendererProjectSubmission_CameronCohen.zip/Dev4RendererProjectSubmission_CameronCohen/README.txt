Camera Control:
W key to move forward
D key to move right
A key to move left
S key to move backwards

Hold down right click to look around

Space to go straight up.

