#pragma once
#include <cstdint>
#include <chrono>
#include "d3d11_renderer_impl.h"
#include "renderer.h"


namespace end
{

	// Simple app class for development and testing purposes
	struct dev_app_t
	{
		KeyInput* keyStates;

		view_t* view;

		XMMATRIX cameraWorld;

		void update(float delta);

		dev_app_t();

		double get_delta_time()const;

		XMMATRIX MouseLook(XMMATRIX _matrix, float deltaX, float deltaY);

		XMMATRIX LookAt(XMVECTOR eye, XMVECTOR at, XMVECTOR up);

		bool GetKeyDown(int key);

		void ChangeColor(float delta);

		void DrawAxes(const XMMATRIX& _matrix);


		renderer_t* renderer;
		

	};
}