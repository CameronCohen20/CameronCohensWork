#include "Defines.h"
#include "RasterSurface.h"
#include "ScreenDraw.h"
#include "Shaders.h"
#include "Math.h"
#include <algorithm>
#include <time.h>
#include <Windows.h>
const char* _cameronCohen;



int main() {
	MATRIX worldMatrix;
	MATRIX cameraMatrix;
	MATRIX projectionMatrix;
	MATRIX idMatrix;
	MATRIX starsMatrix;

	projectionMatrix.matrix[1][1] = cosf(.5f * FOV) / sinf(.5f * FOV);

	projectionMatrix.matrix[0][0] = projectionMatrix.matrix[1][1] * ASPECTRATIO;

	projectionMatrix.matrix[2][2] = FARPLANE / (FARPLANE - NEARPLANE);

	projectionMatrix.matrix[2][3] = 1;

	projectionMatrix.matrix[3][2] = -(FARPLANE * NEARPLANE) / (FARPLANE - NEARPLANE);

	//sets the view(camera) matrix to a perspective 
	//cameraMatrix = BuildRotationMatrixX(-18.0f * PI / 180);
	//cameraMatrix.matrix[3][2] = -1;

	

	// Setting each to the identity matrix
	for (size_t i = 0; i < 4; i++)
	{
		for (size_t j = 0; j < 4; j++)
		{
			if (i - j == 0)
			{
				worldMatrix.matrix[i][j] = 1.0f;

				idMatrix.matrix[i][j] = 1.0f;
			}
		}
	}

	//sets cube matrix as id matrix
	starsMatrix = idMatrix;

	SV_WorldMatrix = idMatrix;

	RS_Initialize(_cameronCohen, _WIDTH, _HEIGHT);


	VERTEX stars[3000];
		
	





	srand(time(NULL));
	float x;
	float y;
	float z;

	for (size_t i = 0; i < 3000; i++)
	{
		x = -1 + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (2)));
		
		y = -1 + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (2)));
		z = -1 + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (2)));
		x = x * 50;
		y = y * 50;
		z = z * 50;

		stars[i].position[0] = x;
		stars[i].position[1] = y;
		stars[i].position[2] = z;

		stars[i].color = 0xFFFFFFFF;

	}

	cameraMatrix = idMatrix;


	VertexShader = VS_3DPipeLine;
	SV_CameraMatrix = cameraMatrix;
	SV_ProjectionMatrix = projectionMatrix;

	while (RS_Update(Raster, _totalPixels))
	{
		std::fill_n(ZBuffer, _totalPixels, 1);

		for (size_t i = 0; i < _totalPixels; i++)
		{
			Raster[i] = 0;
		}

		for (size_t i = 0; i < 3000; i++)
		{
			VERTEX copy = stars[i];

			if (VertexShader)
			{
				VertexShader(copy);
			}

			VERTEX star = NDCtoScreen(copy);
			PlotPixel(star.position[0], star.position[1], star.position[2], star.color);
		}
		if (GetKeyState('W') & 0x8000)
		{
			cameraMatrix = MultiplyMatrixByMatrix(BuildRotationMatrixX(0.01f), cameraMatrix);
		}
		if (GetKeyState('A') & 0x8000)
		{
			cameraMatrix = MultiplyMatrixByMatrix(BuildRotationMatrixY(0.01f), cameraMatrix);
		}
		if (GetKeyState('S') & 0x8000)
		{
			cameraMatrix = MultiplyMatrixByMatrix(BuildRotationMatrixX(-0.01f), cameraMatrix);
		}
		if (GetKeyState('D') & 0x8000)
		{
			cameraMatrix = MultiplyMatrixByMatrix(BuildRotationMatrixY(-0.01f), cameraMatrix);
		}

		SV_CameraMatrix = cameraMatrix;


	}


	RS_Shutdown();

}