#pragma once
#include "Defines.h"
#include <corecrt_math.h>
static VERTEX MultiplyVertexByMatrix(VERTEX vert, MATRIX m);
static VERTEX NDCtoScreen(VERTEX vert);
static MATRIX BuildRotationMatrixY(float rad);
static MATRIX BuildRotationMatrixX(float rad);
//static MATRIX BuildRotationMatrixZ(float rad);
static MATRIX OrthgonalInverseMatrix(MATRIX mat);
static MATRIX MultiplyMatrixByMatrix(MATRIX m, MATRIX m2);

static VERTEX NDCtoScreen(VERTEX vert) {
	VERTEX aPos;

	aPos.color = vert.color;
	aPos.position[0] = (vert.position[0] + 1) * (_WIDTH / 2); //coord conversion 1 + x * width / 2
	aPos.position[1] = (-vert.position[1] + 1) * (_HEIGHT / 2); //coord conversion 1 - y * height / 2
	aPos.position[2] = vert.position[2];
	aPos.position[3] = vert.position[3];
	

	return aPos;
}

MATRIX BuildRotationMatrixY(float rad) {
	MATRIX m;

	m.matrix[0][0] = cosf(rad);
	m.matrix[2][0] = -sinf(rad);
	m.matrix[0][2] = sinf(rad);
	m.matrix[2][2] = cosf(rad);
	m.matrix[1][1] = 1;
	m.matrix[3][3] = 1;

	return m;
}

VERTEX MultiplyVertexByMatrix(VERTEX vert, MATRIX m) {
	VERTEX temp;

	temp.color = vert.color;

	temp.position[3] = 0;

	for (size_t i = 0; i < 4; i++)
	{
		for (size_t j = 0; j < 4; j++)

		{
			temp.position[j] += vert.position[i] * m.matrix[i][j];
		}
	}

	return temp;
}

static MATRIX BuildRotationMatrixX(float rad) {
	MATRIX m;

	m.matrix[1][1] = cosf(rad);
	m.matrix[1][2] = -sinf(rad);
	m.matrix[2][1] = sinf(rad);
	m.matrix[2][2] = cosf(rad);
	m.matrix[0][0] = 1;
	m.matrix[3][3] = 1;
	return m;
}
//
//static MATRIX BuildRotationMatrixZ(float rad) {
//	MATRIX m;
//	m.matrix[0][0] = cosf(rad);
//	m.matrix[0][1] = -sinf(rad);
//	m.matrix[1][0] = sinf(rad);
//	m.matrix[1][1] = cosf(rad);
//	m.matrix[2][2] = 1;
//	m.matrix[3][3] = 1;
//	return m;
//}

static MATRIX OrthgonalInverseMatrix(MATRIX mat) {
	MATRIX m = mat;
	VERTEX temp;

	for (size_t i = 0; i < 3; i++)
	{
		for (size_t j = 0; j < 3; j++)
		{
			if (i != j)
			{
				float temp = mat.matrix[i][j];

				m.matrix[i][j] = mat.matrix[j][i];
				m.matrix[j][i] = temp;
			}
		}
	}


	temp.position[3] = 0;

	for (size_t i = 0; i < 3; i++)
	{
		for (size_t j = 0; j < 3; j++)
		{
			temp.position[j] += mat.matrix[3][i] * mat.matrix[i][j];
		}
	}

	for (size_t i = 0; i < 3; i++)
	{
		temp.position[i] *= -1;

		m.matrix[3][i] = temp.position[i];
	}

	return m;
}

inline MATRIX MultiplyMatrixByMatrix(MATRIX m, MATRIX m2)
{
	MATRIX mat;

	for (size_t i = 0; i < 4; i++)
	{
		for (size_t j = 0; j < 4; j++)
		{
			for (size_t k = 0; k < 4; k++)
			{
				mat.matrix[i][j] += m.matrix[i][k] * m2.matrix[k][j];
			}
		}
	}
	return mat;
}

