﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1BCL
{
    public abstract class Motorized : IVehicle
    {

		public  Motorized(int year, string make, string model, int passengers)
		{
			Year = year;
			Make = make;
			Model = model;
			Passengers = passengers;
		}

		public int Year { get; set; }

		public string Make { get; set; }

		public string Model { get; set; }

		public int Passengers { get; set; }

		public virtual string Display()
		{
			string display = $"{Year} {Make} - {Model} {Passengers}";
			return display;

		}
	}

	public class Dealership
	{
		public IVehicle[] inventory = new IVehicle[4];

		public void AddCar(IVehicle addcar)
		{
			if (inventory.Length > _count)
			{
				inventory[_count++] = addcar;
			}
			else
			{
				Console.WriteLine("Your Inventory Is Full.");
			}
		}

		public Motorized[] _inventory { get; set; }
		public int _count { get; set; }

		public void Display()
		{
			for (int i = 0; i < _count; i++)
			{
				Console.WriteLine(inventory[i].Display());
			}
		}

	}

	public static class Factory
	{
		//public static Motorized CreateCar(int year, string make, string model, int passengers)
		//{
		//	IVehicle newcar = new Motorized(year, make, model, passengers);
		//	return newcar;
		//}
		public static IVehicle CreateTruck(int year, string make, string model, int passengers, int capacity)
		{
			IVehicle newcar = new Truck(year, make, model, passengers, capacity);
			return newcar;
		}

		public static IVehicle CreateMinivan(int year, string make, string model, int passengers, int slidingDoors)
		{
			IVehicle newcar = new Minivan(year, make, model, passengers, slidingDoors);
			return newcar;
		}
	}

}
