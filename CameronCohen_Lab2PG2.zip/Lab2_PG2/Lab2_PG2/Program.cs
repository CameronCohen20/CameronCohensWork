﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;

namespace Lab2_PG2
{
    class Program
    {
        static void Main(string[] args)
        {
            string fName = "speech.csv";
            StreamReader sr = new StreamReader(fName);
            string speech = sr.ReadToEnd();
            sr.Close();
            int menuChoice = 0;
            string[] menu = new string[] { "1.Show Histogram", "2.Search for Word", "3.Save the Histogram Data", "4.Load the Histogram Data", "5.Remove Word", "6.Exit" };
    
            bool check = true;
            string[] words = speech.Split(new char[] { ' ', ',', '!', '.', ';', '?', '-','"', '\n', '\t', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            string[] sentence = speech.Split(new char[] { '.', '!', '?', '\n', '\t', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            List<string> wordList = words.ToList();

            Dictionary<string, int> dict = new Dictionary<string, int>(StringComparer.InvariantCultureIgnoreCase);
            for (int i = 0; i < wordList.Count; i++)
            {
                if (dict.ContainsKey(wordList[i]))
                {
                    dict[wordList[i]]++;
                }
                else
                {
                    dict.Add(wordList[i], 1);
                }
            }

            while (check)
            {

                ReadChoice("You didnt make a valid choice", menu, out menuChoice);
                if (menuChoice == 1)
                {
                    foreach (var x in dict)
                    {
                        char[] bar = new char[x.Value];
                        Console.Write($"{x.Key} ");
                        Console.BackgroundColor = ConsoleColor.Blue;
                        foreach (char y in bar)
                        {
                            Console.Write(y);
                        }
                        Console.ResetColor();
                        Console.WriteLine($" {x.Value}");
                    }
                }
                else if (menuChoice == 2)
                {
                    Console.WriteLine("What word do you want to find?");
                    string search = Console.ReadLine();
                    if (dict.ContainsKey(search))
                    {
                        char[] bar = new char[dict[search]];
                        Console.Write($"{search} ");
                        Console.BackgroundColor = ConsoleColor.Blue;
                        foreach (char x in bar)
                        {
                            Console.Write(x);
                        }
                        Console.ResetColor();
                        Console.WriteLine($" {dict[search]}");
                        foreach (string x in sentence)
                        {
                            string[] xSentence = x.Split(new char[] { ' ', '.', '!', '?', '\n', '\t', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (var y in xSentence)
                            {
                                if (y.ToLower() == search.ToLower())
                                {
                                    Console.WriteLine(x);
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("The word you searched for doesn't exist");
                    }
                }
                else if (menuChoice == 3)
                {
                    Console.WriteLine("You've selected to Save the Histogram");
                    Console.WriteLine("What is your file name?");
                    string save = Console.ReadLine();
                    save = Path.ChangeExtension(save, "json");
                    using (StreamWriter word = File.CreateText(save))
                    {
                        using (JsonTextWriter jtw = new JsonTextWriter(word))
                        {
                            jtw.Formatting = Formatting.Indented;
                            JsonSerializer ser = new JsonSerializer();
                            ser.Serialize(jtw, dict);
                            Console.WriteLine($"You saved the file! Press Enter to Continue");
                        }
                    }
                   
                }
                else if (menuChoice == 4)
                {
                    Console.WriteLine("You've selected to Load the Histogram");
                    Console.WriteLine("What is the name of the file?");
                    string load = Console.ReadLine();
                    load = Path.ChangeExtension(load, "json");
                    if (File.Exists(load))
                    {
                        string jText = File.ReadAllText(load);
                        dict = JsonConvert.DeserializeObject<Dictionary<string, int>> (jText);
                        Console.WriteLine($"You loaded the file {load}. Press Enter to Continue");
                    }
                    else
                    {
                        Console.WriteLine("The file doesn't exist. Press Enter to Continue");
                    }
                }
                else if (menuChoice == 5)
                {
                    Console.WriteLine("What word do you want to remove?");
                    string remove = Console.ReadLine();
                    if (dict.ContainsKey(remove))
                    {
                        dict.Remove(remove);
                        Console.WriteLine($"You removed the word {remove}. Press Enter to Continue");
                    }
                    else
                    {
                        Console.WriteLine($"The word {remove} already doesn't exist. Press Enter to Continue");
                    }

                }

                else if (menuChoice == 6)
                {
                    Console.WriteLine( "You have selected Exit" );
                    Console.WriteLine( "Goodbye!" );
                    check = false;
                }
                Console.ReadKey();
                Console.Clear();
            }


        }

        static void ReadChoice(string prompt, string[] options, out int selection)
        {
            foreach (string x in options)
            {
                Console.WriteLine(x);
            }
            selection = ReadInteger("Choice:");
        }

        static int ReadInteger(string Integer)
        {
            int x = 0;

            while (true)
            {
                Console.WriteLine(Integer);
                if (Int32.TryParse(Console.ReadLine(), out x))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error!! You did not make a valid input");
                }
            }

            return x;
        }

    }
} 
