#pragma once


struct KeyInput
{
	int keyStates[91] = { 0 };

	int GetState(int index) {
		if (index > 90 || index < 0)
		{
			return -1;
		}

		keyStates[index];
	}

	void SetState(int index, int val) {
		if (index > 90 || index < 0)
		{
			return;
		}
		keyStates[index] = val;
	}

	int operator[](int index) {
		if (index > 90 || index < 0)
		{
			return -1;
		}

		return keyStates[index];
	}

};