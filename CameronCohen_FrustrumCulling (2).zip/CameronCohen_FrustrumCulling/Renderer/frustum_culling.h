#pragma once
#include <array>

#include "math_types.h"
#include <DirectXMath.h>
#include "debug_renderer.h"

using namespace DirectX;

// Note: You are free to make adjustments/additions to the declarations provided here.

namespace end
{
	struct sphere_t { XMVECTOR center; float radius; }; //Alterative: using sphere_t = float4;


	//Next time use the center and extents
	struct aabb_t { float3 center; float3 extents; }; //Alternative: aabb_t { float3 min; float3 max; };

	struct plane_t { XMVECTOR normal; float offset; };  //Alterative: using plane_t = float4;

	using frustum_t = std::array<plane_t, 6>;

	// Calculates the plane of a triangle from three points.
	plane_t calculate_plane(XMVECTOR a, XMVECTOR b, XMVECTOR c)
	{
		plane_t final;

		XMVECTOR cross = XMVector3Normalize(XMVector3Cross(b - a, c - a));
		final.normal = cross;
		final.offset = XMVectorGetX(XMVector3Dot(cross, a));
		return final;
	}

	//Calculates the center of a plane given the 4 corners
	XMVECTOR calculateCenter(XMVECTOR a, XMVECTOR b, XMVECTOR c, XMVECTOR d)
	{
		float x = (XMVectorGetX(a) + XMVectorGetX(b) + XMVectorGetX(c) + XMVectorGetX(d)) / 4;
		float y = (XMVectorGetY(a) + XMVectorGetY(b) + XMVectorGetY(c) + XMVectorGetY(d)) / 4;
		float z = (XMVectorGetZ(a) + XMVectorGetZ(b) + XMVectorGetZ(c) + XMVectorGetZ(d)) / 4;
		XMVECTOR result = { x, y, z };
		return result;
	}

	// Calculates a frustum (6 planes) from the input view parameter.
	//
	// Calculate the eight corner points of the frustum. 
	// Use your debug renderer to draw the edges.
	// 
	// Calculate the frustum planes.
	// Use your debug renderer to draw the plane normals as line segments.
	void calculate_frustum(frustum_t& frustum, XMMATRIX& view)
	{
		//position
		//direction

		float nearDistance = 0.1f;
		float farDistance = 10.0f;
		float fov = 45 * (3.141591f / 180); // 91 degrees (90 degree causes a divide by zero error)
		float height = 1.0f;
		float width = 1.5;
		float aspect = width / height;
		float halfHeight = tan(fov / 2.0f) * nearDistance;
		float halfWidth = halfHeight * aspect;
		float farHalfHeight = tan(fov / 2.0f) * farDistance;
		float farHalfWidth = farHalfHeight * aspect;

		XMVECTOR color = { 1, 0, 1, 1 };

		//Near Plane
		//Each time we move in the directions defined by view
		//Grab center first
		XMVECTOR nearCenter = view.r[3] + nearDistance * view.r[2];
		//Move up halfHeight and right halfWidth
		XMVECTOR nearTopRight = nearCenter + view.r[0] * halfWidth + view.r[1] * halfHeight;
		//Move up halfHeight and left halfWidth
		XMVECTOR nearTopLeft = nearCenter + view.r[0] * -halfWidth + view.r[1] * halfHeight;
		//Move down halfHeight and left halfWidth
		XMVECTOR nearBottomLeft = nearCenter + view.r[0] * -halfWidth + view.r[1] * -halfHeight;
		//Move down halfHeight and right halfWidth
		XMVECTOR nearBottomRight = nearCenter + view.r[0] * halfWidth + view.r[1] * -halfHeight;

		//Far Plane
		//Each time we move in the directions defined by view
		//Grab center first
		XMVECTOR farCenter = view.r[3] + farDistance * view.r[2];
		//Move up farHalfHeight and right farHalfWidth
		XMVECTOR farTopRight = farCenter + view.r[0] * farHalfWidth + view.r[1] * farHalfHeight;
		//Move up farHalfHeight and left farHalfWidth
		XMVECTOR farTopLeft = farCenter + view.r[0] * -farHalfWidth + view.r[1] * farHalfHeight;
		//Move down farHalfHeight and left farHalfWidth
		XMVECTOR farBottomLeft = farCenter + view.r[0] * -farHalfWidth + view.r[1] * -farHalfHeight;
		//Move down farHalfHeight and right farHalfWidth
		XMVECTOR farBottomRight = farCenter + view.r[0] * farHalfWidth + view.r[1] * -farHalfHeight;

		//near plane
		frustum[0] = calculate_plane(nearTopLeft, nearTopRight, nearBottomRight);
		//right side
		frustum[1] = calculate_plane(nearTopRight, farTopRight, farBottomRight);
		//left side
		frustum[2] = calculate_plane(nearTopLeft, nearBottomLeft, farBottomLeft);
		//top side
		frustum[3] = calculate_plane(nearTopLeft, farTopLeft, farTopRight);
		//bot side
		frustum[4] = calculate_plane(nearBottomLeft, nearBottomRight, farBottomRight);
		//back side
		frustum[5] = calculate_plane(farTopRight, farTopLeft, farBottomLeft);

		//Drawing

		//Near Plane
		debug_renderer::add_line(nearTopLeft, nearTopRight, color);
		debug_renderer::add_line(nearBottomRight, nearTopRight, color);
		debug_renderer::add_line(nearTopLeft, nearBottomLeft, color);
		debug_renderer::add_line(nearBottomLeft, nearBottomRight, color);

		//Far Plane
		debug_renderer::add_line(farTopLeft, farTopRight, color);
		debug_renderer::add_line(farBottomRight, farTopRight, color);
		debug_renderer::add_line(farTopLeft, farBottomLeft, color);
		debug_renderer::add_line(farBottomLeft, farBottomRight, color);

		//Connecting
		debug_renderer::add_line(nearTopLeft, farTopLeft, color);
		debug_renderer::add_line(farTopRight, nearTopRight, color);
		debug_renderer::add_line(farBottomLeft, nearBottomLeft, color);
		debug_renderer::add_line(farBottomRight, nearBottomRight, color);

		//Normals
		XMVECTOR normalColor = { 0,0,1,1 };

		//Near Plane 
		debug_renderer::add_line(nearCenter, frustum[0].normal + nearCenter, color, normalColor);

		//Right Plane
		XMVECTOR rightCenter = calculateCenter(nearTopRight, nearBottomRight, farTopRight, farBottomRight);
		debug_renderer::add_line(rightCenter, frustum[1].normal + rightCenter, color, normalColor);

		//Left Plane
		XMVECTOR leftCenter = calculateCenter(nearTopLeft, nearBottomLeft, farTopLeft, farBottomLeft);
		debug_renderer::add_line(leftCenter, frustum[2].normal + leftCenter, color, normalColor);

		//Top Plane
		XMVECTOR topCenter = calculateCenter(nearTopLeft, nearTopRight, farTopLeft, farTopRight);
		debug_renderer::add_line(topCenter, frustum[3].normal + topCenter, color, normalColor);

		//Bottom Plane
		XMVECTOR botCenter = calculateCenter(nearBottomLeft, nearBottomRight, farBottomLeft, farBottomRight);
		debug_renderer::add_line(botCenter, frustum[4].normal + botCenter, color, normalColor);
		//Far Plane
		debug_renderer::add_line(farCenter, frustum[5].normal + farCenter, color, normalColor);
	}


	// Calculates which side of a plane the sphere is on.
	//
	// Returns -1 if the sphere is completely behind the plane.
	// Returns 1 if the sphere is completely in front of the plane.
	// Otherwise returns 0 (Sphere overlaps the plane)
	int classify_sphere_to_plane(const sphere_t& sphere, const plane_t& plane)
	{
		float distanceToPlane = XMVectorGetX(XMVector3Dot(sphere.center, plane.normal)) - plane.offset;
		//omg he on x-games mode
		int result = (distanceToPlane > sphere.radius) ? 1 : (distanceToPlane < -sphere.radius) ? -1 : 0;
		return result;
	}

	// Calculates which side of a plane the aabb is on.
	//
	// Returns -1 if the aabb is completely behind the plane.
	// Returns 1 if the aabb is completely in front of the plane.
	// Otherwise returns 0 (aabb overlaps the plane)
	// MUST BE IMPLEMENTED UsING THE PROJECTED RADIUS TEST
	int classify_aabb_to_plane(const aabb_t& aabb, const plane_t& plane)
	{
		XMVECTOR extents = { aabb.extents.x, aabb.extents.y, aabb.extents.z };
		XMVECTOR normal = { std::abs(XMVectorGetX(plane.normal)), std::abs(XMVectorGetY(plane.normal)), std::abs(XMVectorGetZ(plane.normal)) };
		float radius = XMVectorGetX(XMVector3Dot(extents, normal));
		sphere_t sphere;
		sphere.center = XMVectorSet(aabb.center.x, aabb.center.y, aabb.center.z, 0);
		sphere.radius = radius;
		return classify_sphere_to_plane(sphere, plane);
	}

	// Determines if the aabb is inside the frustum.
	//
	// Returns false if the aabb is completely behind any plane.
	// Otherwise returns true.
	bool aabb_to_frustum(const aabb_t& aabb, const frustum_t& frustum)
	{
		int result = 0;
		for (size_t i = 0; i < frustum.size(); i++)
		{
			result = classify_aabb_to_plane(aabb, frustum[i]);
			if (result == 1)
				return false;
		}
		return true;
	}
}