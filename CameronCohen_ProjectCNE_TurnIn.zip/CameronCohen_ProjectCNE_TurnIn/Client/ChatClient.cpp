#include "ChatClient.h"

ChatClient::ChatClient()
{
}

bool ChatClient::init(string ip_address, uint16_t port)
{
	int result;
	WSADATA wsaData;

	result = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (result != 0)
	{
		printf("CLIENT: WSAStartup failed with error: %d\n", result);
		return false;
	}

	connectSocket = socket(AF_UNSPEC, SOCK_STREAM, IPPROTO_TCP);
	if (connectSocket == INVALID_SOCKET)
	{
		cout << "CLIENT: Failed to create socket" << endl;
		WSACleanup();
		return false;
	}

	//Address stuff
	sockaddr_in serverAddress;
	serverAddress.sin_family = AF_INET; //give it a family :)
	serverAddress.sin_port = htons(port);

	//Setting the address
	if (inet_pton(AF_INET, ip_address.c_str(), &serverAddress.sin_addr) < 0)
	{
		cout << "CLIENT: Invalid address" << endl;
		return false;
	}

	//Connect
	result = connect(connectSocket, (SOCKADDR*)&serverAddress, sizeof(serverAddress));
	if (result == SOCKET_ERROR)
	{
		cout << "CLIENT: Couldn't connect" << endl;
		return false;
	}

	cout << "CLIENT: CONNECTED" << endl;

	//Prompt for a username
	cout << "CLIENT: What's your username? " << endl;
	cin >> username;

	string buffer = "$register " + username;
	int length = buffer.size();
	int bytes = sendMessage(connectSocket, (const char*)&length, 2);
	bytes = sendMessage(connectSocket, buffer.c_str(), length);

	string answer = recServerMessage();

	if (answer[0] == SV_FULL)
	{
		cout << "CLIENT: SERVER IS FULL" << endl;
		closesocket(connectSocket);
		return false;
	}
	else if (answer[0] == SV_SUCCESS)
	{
		cout << "CLIENT: REGISTERED" << endl;
	}
	else
	{
		cout << "CLIENT: INVALID MESSAGE FROM SERVER" << endl;
		closesocket(connectSocket);
		return false;
	}

	return true;
}


bool ChatClient::run(void)
{
	string buffer = recServerMessage();

	//New client joins. Announce their arrival
	if (buffer == "$add")
	{

	}
	//Client left. Announce their departure
	else if (buffer == "$remove")
	{

	}
	//Server closes
	else if (buffer == "$exit")
	{
		closesocket(connectSocket);
		return false;
	}
	//Client message
	else
	{
		cout << buffer << endl;
	}

	return true;
}

SOCKET ChatClient::getSocket()
{
	return connectSocket;
}

string ChatClient::recServerMessage()
{
	int length = 0;
	int bytesReceived = recMessage(connectSocket, (char*)&length, 2, 0);
	char* buffer = new char[length];
	bytesReceived = recMessage(connectSocket, buffer, length, 0);
	return string(buffer);
}


