#include "defines.h"
#include "ScreenDraw.h"
#include <stdlib.h>
#include <Windows.h>
const char* _cameronCohen;



int main() {
	RS_Initialize(_cameronCohen, _WIDTH, _HEIGHT);

	srand(time_t(NULL));
	int x;
	int y;

	//randomizes the stars
	for (size_t i = 0; i < 2000; i++)
	{
		x = rand() % 500;
		y = rand() % 500;
		PlotPixel(x, y, 0xFFFFFFFF);
	}

	VERTEX_2D lines[12] = {
		{ {0,100}, 0xFF914F37},
		{ {499,400}, 0xFF914F37}, //bresenhem
		{ {0,110}, 0xFF914F37},
		{ {499,410}, 0xFF914F37}, 
		{ {0,120}, 0xFFFF00FF},
		{ {499,420}, 0xFF00FFFF},

		{ {0,0}, 0xFFFF00FF},
		{ {0,0}, 0xFF00FFFF},
		{ {0,0}, 0xFFFF00FF},
		{ {0,0}, 0xFF00FFFF},
		{ {0,0}, 0xFFFF00FF},
		{ {0,0}, 0xFF00FFFF}
	};

	bool randLines = false;
	
	while (RS_Update(Raster, _TOTALPIXELS))
	{

		if (GetKeyState('E')){
		
			randLines = true;
		}

		if (randLines){ //makes the random lines appear
			
			unsigned int color = 0;
			for (size_t i = 0; i < _TOTALPIXELS; i++)
			{
				Raster[i] = color;
			}

			lines[6].position.x = rand() % 500;
			lines[6].position.y = rand() % 500;
			lines[7].position.x = rand() % 500;
			lines[7].position.y = rand() % 500;



			BresenhamLine(lines[6], lines[7]);

			PlotPixel(lines[6].position.x, lines[6].position.y, 0xFFFFFF00);

			PlotPixel(lines[7].position.x, lines[7].position.y, 0xFFFFFF00);


			lines[8].position.x = rand() % 500;
			lines[8].position.y = rand() % 500;
			lines[9].position.x = rand() % 500;
			lines[9].position.y = rand() % 500;


			MidPointLine(lines[8], lines[9]);

			PlotPixel(lines[8].position.x, lines[8].position.y, 0xFFFFFF00);

			PlotPixel(lines[9].position.x, lines[9].position.y, 0xFFFFFF00);


			lines[10].position.x = rand() % 500;
			lines[10].position.y = rand() % 500;
			lines[11].position.x = rand() % 500;
			lines[11].position.y = rand() % 500;


			ParametricLine(lines[10], lines[11]);

			PlotPixel(lines[10].position.x, lines[10].position.y, 0xFFFFFF00); 

			PlotPixel(lines[11].position.x, lines[11].position.y, 0xFFFFFF00);

		}
		else  //keeps the lines in a fix position
		{
			ParametricLine(lines[4], lines[5]);

			BresenhamLine(lines[0], lines[1]);

			MidPointLine(lines[2], lines[3]);
		}




	}



	RS_Shutdown();
}