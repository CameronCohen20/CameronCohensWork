#include "dev_app.h"
#include "math_types.h"
#include "debug_renderer.h"
#include <iostream>
//TODO include debug_renderer.h and pools.h and anything else you might need here
#include "../pools.h"
#include <vector>
#include "KeyPresses.h"
#include <wtypes.h>
#include "d3d11_renderer_impl.h"







namespace end
{
	using namespace DirectX;

	double delta_time = 0.0;
	end::float4 lColor;
	end::float3 colorDirection;
	end::Emitter emitter;
	end::pool_t<Particle, 1024> s_pool;
	std::vector<end::FreeEmitter> f_emitter;

	XMMATRIX axes1, axes2, axes3;

	std::chrono::steady_clock::time_point previousFrame;

	POINT prevMouse;

	end::float4 lineColor = { 0.0f, 1.0f, 0.0, 0.0 };

	XMMATRIX cameraWorld;

	struct aabb_t { float3 center; float3 extents; }; //Alternative: aabb_t { float3 min; float3 max; };

	struct plane_t { XMVECTOR normal; float offset; };  //Alterative: using plane_t = float4;

	using frustum_t = std::array<plane_t, 6>;


	double dev_app_t::get_delta_time()const
	{
		return delta_time;
	}

	float rand_float(float min, float max)
	{
		float ratio = rand() / static_cast<float>(RAND_MAX);
		return (max - min) * ratio + min;
	}

	void InsertParticleIntoEmitter(Emitter& emitter, float delta) {

		/*int spawnAmmount = delta * emitter.pool.capacity() + emitter.pool.size();
		spawnAmmount = (spawnAmmount > emitter.pool.capacity()) ? emitter.pool.capacity() : spawnAmmount;*/

		int spawnAmount = 50;

		for (size_t i = emitter.pool.size(); i < spawnAmount; i++)
		{
			uint16_t index = emitter.pool.alloc();

			if (index != -1)
			{
				float3 velocity = float3(rand_float(-1, 1), rand_float(10.0f, 20.0f), rand_float(-1.0f, 1.0f));

				Particle p = Particle(emitter.pos, emitter.color, velocity, rand_float(0.3f, 5.0f));

				emitter.pool[index] = p;
			}
		}
	}

	void dev_app_t::ChangeColor(float delta) {

		lineColor.x = lineColor.x + delta * 0.2f * colorDirection.x;
		lineColor.y = lineColor.y + delta * 0.3f * colorDirection.y;
		lineColor.z = lineColor.z + delta * 0.6f * colorDirection.z;

		//if the color of the line(x) is more than or equal to 1 and if the line color is less than or equal to 0
		if (lineColor.x >= 1.0f || lineColor.x <= 0.0f)
		{
			lineColor.x = (lineColor.x >= 1.0f) ? 1 : 0;
			colorDirection.x *= -1;
		}
		//if the color of the line(x) is more than or equal to 1 and if it is less than or equal to 0
		if (lineColor.y >= 1.0f || lineColor.y <= 0.0f)
		{
			lineColor.y = (lineColor.y >= 1.0f) ? 1 : 0;
			colorDirection.y *= -1;
		}
		if (lineColor.z >= 1.0f || lineColor.z <= 0.0f)
		{
			lineColor.z = (lineColor.z >= 1.0f) ? 1 : 0;
			colorDirection.z *= -1;
		}
	}


	void InsertParticleIntoFreeEmitter(FreeEmitter& emitter, float delta) {
		/*int spawnAmmount = delta * emitter.indices.capacity() + emitter.indices.size();
		spawnAmmount = (spawnAmmount > emitter.indices.capacity()) ? emitter.indices.capacity() : spawnAmmount;*/

		int spawnAmount = 50;
		for (size_t i = 0; i < spawnAmount; i++)
		{
			int16_t poolIndex = s_pool.alloc();
			if (poolIndex != -1)
			{
				uint16_t index = emitter.indices.alloc();
				if (index != -1)
				{
					float3 velocity = float3(rand_float(-1, 1), rand_float(10.0f, 20.0f), rand_float(-1.0f, 1.0f));
					Particle p = Particle(emitter.pos, emitter.color, velocity, rand_float(0.3f, 5.0f));
					s_pool[poolIndex] = p;
					emitter.indices[index] = poolIndex;
				}
				else
				{
					s_pool.free(poolIndex);
				}
			}
		}
	}

	void UpdateParticlesInSortedEmitter(Emitter& emitter, float delta) {

		for (size_t i = 0; i < emitter.pool.size(); i++)
		{
			Particle& p = emitter.pool[i];

			if (p.lifeTime <= 0.0f || p.pos.y < emitter.pos.y)
			{
				emitter.pool.free(i);
				i--;
				continue;
			}
			p.Move(0.01f);
		}
	}

	void UpdateParticlesInFreeEmitter(FreeEmitter& emitter, float delta) {
		for (size_t i = 0; i < emitter.indices.size(); i++)
		{
			Particle& p = s_pool[emitter.indices[i]];
			if (p.lifeTime <= 0.0f || p.pos.y < emitter.pos.y)
			{
				s_pool.free(emitter.indices[i]);
				emitter.indices.free(i);
				i--;
				continue;
			}
			p.Move(0.01f);
		}
	}

	bool dev_app_t::GetKeyDown(int key)
	{
		if (keyStates->GetState(key) == 1 || keyStates->GetState(key) == 2)
		{
			return true;
		}


		return false;
	}

	XMMATRIX Orthonormalize(XMMATRIX mat)
	{
		XMVECTOR xAxis, yAxis, zAxis, up;

		up = XMVectorSet(0, 1, 0, 0);
		zAxis = mat.r[2];

		xAxis = XMVector3Normalize(XMVector3Cross(up, zAxis));
		yAxis = XMVector3Normalize(XMVector3Cross(zAxis, xAxis));

		XMMATRIX final = { xAxis, yAxis, zAxis, mat.r[3] };
		return final;
	}

	XMMATRIX dev_app_t::MouseLook(XMMATRIX _matrix, float deltaX, float deltaY)
	{
		XMVECTOR pos = _matrix.r[3];

		_matrix = XMMatrixMultiply(XMMatrixRotationX(deltaY), _matrix);
		_matrix = XMMatrixMultiply(XMMatrixRotationY(deltaX), _matrix);

		return Orthonormalize(_matrix);
	}

	void dev_app_t::DrawAxes(const XMMATRIX& _matrix) {

		end::float3 _position = *(float3*)&_matrix.r[3];

		end::float3 endx = _position + *(float3*)&_matrix.r[0];
		end::float3 endy = _position + *(float3*)&_matrix.r[1];
		end::float3 endz = _position + *(float3*)&_matrix.r[2];

		end::debug_renderer::add_line(_position, endx, float4(1.0f, 0.0f, 0.0f, 1.0f));
		end::debug_renderer::add_line(_position, endy, float4(0.0f, 1.0f, 0.0f, 1.0f));
		end::debug_renderer::add_line(_position, endz, float4(0.0f, 0.0f, 1.0f, 1.0f));
	}

	XMMATRIX dev_app_t::LookAt(XMVECTOR eye, XMVECTOR at, XMVECTOR up)
	{
		XMMATRIX _final;
		_final.r[3] = eye;
		_final.r[2] = XMVector3Normalize(at - eye);
		_final.r[0] = XMVector3Normalize(XMVector3Cross(up, _final.r[2]));
		_final.r[1] = XMVector3Normalize(XMVector3Cross(_final.r[2], _final.r[0]));
		return _final;
	}

	XMMATRIX TurnTo(XMMATRIX looker, XMVECTOR at, float speed)
	{
		XMVECTOR pos = looker.r[3];
		XMVECTOR toTarget = at - looker.r[3];
		float dotY = XMVectorGetX(XMVector3Dot(toTarget, looker.r[0]));
		float dotX = XMVectorGetX(XMVector3Dot(toTarget, looker.r[1]));

		XMMATRIX rotationX = XMMatrixRotationX(-dotX * speed);
		XMMATRIX rotationY = XMMatrixRotationY(dotY * speed);

		looker = XMMatrixMultiply(rotationX, looker);
		looker = XMMatrixMultiply(rotationY, looker);

		looker.r[3] = pos;


		//Keep in mind that this breaks a little bit when the target is directly below
		return Orthonormalize(looker);
	}

	void FaceHelper(end::float3 a, end::float3 b, end::float4 color)
	{
		int valuesShared = 0;
		if (a.x == b.x)
			valuesShared++;
		if (a.y == b.y)
			valuesShared++;
		if (a.z == b.z)
			valuesShared++;

		if (valuesShared == 2)
			end::debug_renderer::add_line(a, b, color);
	}

	void DrawFace(end::float3 a, end::float3 b, end::float3 c, end::float3 d, end::float4 color)
	{
		FaceHelper(a, b, color);
		FaceHelper(a, c, color);
		FaceHelper(a, d, color);
		FaceHelper(b, c, color);
		FaceHelper(b, d, color);
		FaceHelper(d, c, color);
	}



	void DrawAABB(end::aabb_t box, end::float4 color)
	{
		end::float3 max = box.center + box.extents;
		end::float3 min = box.center - box.extents;
		float height = max.y - min.y;
		end::float3 a, b, c, d;
		a = min;
		b = end::float3(min.x, min.y, max.z);
		c = end::float3(max.x, min.y, max.z);
		d = end::float3(max.x, min.y, min.z);
		end::float3 w, x, y, z;
		w = end::float3(a.x, a.y + height, a.z);
		x = end::float3(b.x, b.y + height, b.z);
		y = end::float3(c.x, c.y + height, c.z);
		z = end::float3(d.x, d.y + height, d.z);

		DrawFace(a, b, c, d, color);
		DrawFace(a, w, z, d, color);
		DrawFace(a, b, w, x, color);
		DrawFace(x, b, c, y, color);
		DrawFace(y, z, c, d, color);
		DrawFace(w, x, y, z, color);
	}

	dev_app_t::dev_app_t()
	{
		std::cout << "Log whatever you need here.\n"; // Don�t forget to include <iostream>

		axes1 = XMMatrixTranslation(0, 0.1f, 0);
		axes2 = XMMatrixTranslation(-5, 2, 3);
		axes3 = XMMatrixTranslation(5, 2, 3);
	}

	double calc_delta_time()
	{
		static std::chrono::time_point<std::chrono::high_resolution_clock> last_time = std::chrono::high_resolution_clock::now();

		std::chrono::time_point<std::chrono::high_resolution_clock> new_time = std::chrono::high_resolution_clock::now();
		std::chrono::duration<double> elapsed_seconds = new_time - last_time;
		last_time = new_time;

		return min(1.0 / 15.0, elapsed_seconds.count());
	}

	void dev_app_t::update(float delta)
	{
		POINT mousePos;
		GetCursorPos(&mousePos);
		auto now = std::chrono::steady_clock::now();
		float timeElapsed = std::chrono::duration_cast<std::chrono::microseconds>(now - previousFrame).count();
		timeElapsed /= 1000000;


		delta = 0.0010f;


		ChangeColor(delta);
		emitter.color = { 1.0f, 1.0f, 1.0f, 1.0f };
		//This drawn the green checkmark
		const int length = 21;
		end::float4 color = lineColor;
		emitter.color = lineColor;
		end::float3 grid[length * length] = {};

		float sped = 10.0f;
		int a, b, c, d;
		float x = 0;
		float z = 0;

		for (int i = 0; i < length; i++)
		{
			z = i;
			for (int j = 0; j < length; j++)
			{
				x = j;
				grid[j + i * length] = { (-1 + x / (length / 2)) * length, 0, (-1 + z / (length / 2)) * length };
			}
		}

		for (size_t i = 0; i < length - 1; i++)
		{
			a = 0 + i * length;
			b = 1 + i * length;
			c = length + i * length;
			d = length + 1 + i * length;

			for (size_t j = 0; j < length - 1; j++)
			{
				if (i == 0)
				{
					end::debug_renderer::add_line(grid[a], grid[b], color);
				}


				end::debug_renderer::add_line(grid[a], grid[c], color);
				end::debug_renderer::add_line(grid[b], grid[d], color);
				end::debug_renderer::add_line(grid[c], grid[d], color);
				a++;
				b++;
				c++;
				d++;
			}
			DrawAxes(axes1);
			DrawAxes(axes2);
			DrawAxes(axes3);

			/*end::debug_renderer::add_line(float3(-2, 0, 0), float3(0, -3, 0), float4(0.1f, 1, 0.1f, 1));
			end::debug_renderer::add_line(float3(0, -3, 0), float3(3, 4, 0), float4(0.1f, 1, 0.1f, 1));*/

			//int linesAdded = end::debug_renderer::get_line_vert_count();
			//

			////TODO do you Updates here
			//InsertParticleIntoEmitter(emitter, delta);

			//UpdateParticlesInSortedEmitter(emitter, delta);

			//for (size_t i = 0; i < emitter.pool.size(); i++)
			//{
			//	end::debug_renderer::add_line(emitter.pool[i].pos, emitter.pool[i].prevPos, emitter.color);
			//}

			//linesAdded = end::debug_renderer::get_line_vert_count();

			//for (FreeEmitter& emit : f_emitter)
			//{
			//	InsertParticleIntoFreeEmitter(emit, delta);
			//	UpdateParticlesInFreeEmitter(emit, delta);

			//	for (size_t i = 0; i < emit.indices.size(); i++)
			//	{
			//		int16_t index = emit.indices[i];
			//		end::debug_renderer::add_line(s_pool[index].pos, s_pool[index].prevPos, emit.color);
			//	}
			//}

			//linesAdded = end::debug_renderer::get_line_vert_count();

			XMMATRIX cameraControl = (XMMATRIX&)view->view_mat;
			float cSpeed = 5.0f;
			float cRotationSpeed = 0.001f;
			float cameraChange = cSpeed * timeElapsed;
			bool cameraMove = false;


			//Axis 1
			if (GetAsyncKeyState(VK_UP)) {
				axes1.r[3] += axes1.r[2] * sped * delta;
			}

			if (GetAsyncKeyState(VK_DOWN)) {
				axes1.r[3] += axes1.r[2] * -sped * delta;
			}
			if (GetAsyncKeyState(VK_LEFT))
			{
				/*XMVECTOR ogPos = axes1.r[3];*/
				axes1.r[3] = XMVectorSet(0, 0, 0, 1);
				axes1 = XMMatrixMultiply(axes1, XMMatrixRotationY(-sped * delta));
				/*axes1.r[3] = ogPos;*/
			}
			if (GetAsyncKeyState(VK_RIGHT))
			{
				XMVECTOR ogPos = axes1.r[3];
				axes1.r[3] = XMVectorSet(0, 0, 0, 1);
				axes1 = XMMatrixMultiply(axes1, XMMatrixRotationY(sped * delta));
				axes1.r[3] = ogPos;
			}

			axes2 = LookAt(axes2.r[3], axes1.r[3], XMVectorSet(0, 1, 0, 0));

			axes3 = TurnTo(axes3, axes1.r[3], 0.5f * delta);



			cameraWorld = (XMMATRIX&)renderer->default_view.view_mat;


			//camera movement
			if (GetAsyncKeyState(VK_RBUTTON))
			{
				float deltaX = mousePos.x - prevMouse.x;
				float deltaY = mousePos.y - prevMouse.y;

				deltaX *= delta;
				deltaY *= delta;

				cameraWorld = MouseLook(cameraWorld, deltaX, deltaY);
			}

			if (GetAsyncKeyState('W'))
			{
				cameraWorld.r[3] += cameraWorld.r[2] * cameraChange;
			}
			if (GetAsyncKeyState('S'))
			{
				cameraWorld.r[3] += cameraWorld.r[2] * -sped * delta;
			}
			if (GetAsyncKeyState('A'))
			{
				cameraWorld.r[3] += cameraWorld.r[0] * -sped * delta;
			}
			if (GetAsyncKeyState('D'))
			{
				cameraWorld.r[3] += cameraWorld.r[0] * sped * delta;
			}

			renderer->default_view.view_mat = (float4x4_a&)cameraWorld;



			

			prevMouse = mousePos;

			previousFrame = now;
			
		}
	}
}
