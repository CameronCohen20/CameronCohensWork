 //minimalistic code to draw a single triangle, this is not part of the API.
 //required for compiling shaders on the fly, consider pre-compiling instead
#include <d3dcompiler.h>
#include <DirectXMath.h>
#include "Gateware.h"
#include "FSLogo.h"
using namespace DirectX;
using namespace std;
#pragma comment(lib, "d3dcompiler.lib")
#define FAR_PLANE 100.0f
#define NEAR_PLANE 0.1f
// Simple Vertex Shader
const char* vertexShaderSource = R"(
#pragma pack_matrix(row_major)
cbuffer ConstantBuffer : register(b0)
{
	matrix w, v, p;
	float4 lightDir, lightColor;
}

struct InputVertex
{
	float3 pos : POSITION;
	float3 uv : UV;
	float3 normal : NORMAL;
};

struct VS_OUT
{
	float4 posH: SV_POSITION;
	float3 uv : UV;
	float3 normal : NORMAL;
};

// an ultra simple hlsl vertex shader
VS_OUT main(InputVertex input)
{
	VS_OUT output = (VS_OUT)0;
	float4 pos = float4(input.pos, 1);
	pos = mul(pos, w);
	pos = mul(pos, v);
	pos = mul(pos, p);

	output.posH = pos;
	output.uv = input.uv;
	output.normal = input.normal;
	return output;
}
)";
// Simple Pixel Shader
const char* pixelShaderSource = R"(
cbuffer ConstantBuffer : register(b0)
{
	matrix w, v, p;
	float4 lightDir, lightColor;
	
}

struct InputPixel
{
	float3 pos : POSITION;
	float3 uv : UV;
	float3 normal : NORMAL;
};

struct PS_OUT
{
	


};

// an ultra simple hlsl pixel shader
float4 main(InputPixel input) : SV_TARGET 
{	
	
	float light_ratio = saturate(dot(-normalize(lightDir.xyz), normalize(input.normal)));
	
	float4 result = float4(1.0f, 1.0f, 1.0f, 1.0f) * light_ratio;

	result = lightColor * light_ratio;

	return result;	
	
}
)";
// Creation, Rendering & Cleanup
class Renderer
{
	// proxy handles
	GW::SYSTEM::GWindow win;
	GW::GRAPHICS::GDirectX11Surface d3d;
	// what we need at a minimum to draw a triangle
	Microsoft::WRL::ComPtr<ID3D11Buffer>		vertexBuffer;
	Microsoft::WRL::ComPtr<ID3D11VertexShader>	vertexShader;
	Microsoft::WRL::ComPtr<ID3D11Buffer>		vertexBufferLevel2;
	Microsoft::WRL::ComPtr<ID3D11Buffer>		indexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer>		indexBufferLevel2;
	Microsoft::WRL::ComPtr<ID3D11PixelShader>	pixelShader;
	Microsoft::WRL::ComPtr<ID3D11InputLayout>	vertexFormat;
	Microsoft::WRL::ComPtr<ID3D11Buffer>		constantBuffer;
	struct MaterialBuffer {

	};
	struct ConstantBuffer
	{
		XMMATRIX w, v, p; //position variables
		XMVECTOR lightDir, lightColor; //light variables
	};

	ConstantBuffer cb;
	bool levelOne = true;
	bool levelTwo = false;

	/*XMMATRIX GridWorld1, GridWorld2, GridWorld3, GridWorld4, GridWorld5, GridWorld6;*/
	std::chrono::steady_clock::time_point previousFrame;
	POINT previousMousePos;
public:
	Renderer(GW::SYSTEM::GWindow _win, GW::GRAPHICS::GDirectX11Surface _d3d)
	{
		win = _win;
		d3d = _d3d;
		ID3D11Device* creator;
		d3d.GetDevice((void**)&creator);
		// Create Vertex Buffer
		float verts[FSLogo_vertexcount] = { 0, };
		/*
		float verts[208] = {0,};
		for (size_t i = 0; i < 26; i++)
		{
			verts[i * 2 * 4 + 1] = 0.5f; //top y value
			verts[i * 2 * 4 + 3] = -0.5f; //bottom y value
			verts[i * 2 * 4 + 4] = -0.5f; //left x value
			verts[i * 2 * 4 + 6] = 0.5f; //right x value

			verts[i * 2 * 4] = -0.5f + (i / 25.0f); //top x value
			verts[i * 2 * 4 + 2] = -0.5f + (i / 25.0f); // bottom x value
			verts[i * 2 * 4 + 5] = 0.5f - (i / 25.0f); //left y value
			verts[i * 2 * 4 + 7] = 0.5f - (i / 25.0f); //right y value



		}
		float pi = 3.14159f;

		GridWorld1 = XMMatrixRotationX(pi / 2);
		GridWorld1.r[3] = XMVectorSet(0, -0.5f, 0, 1);

		GridWorld2= XMMatrixRotationX(pi / 2);
		GridWorld2.r[3] = XMVectorSet(0, 0.5f, 0, 1);

		GridWorld3 = XMMatrixRotationY(0.0f);
		GridWorld3.r[3] = XMVectorSet(0.0f, 0.0f, 0.5f, 1);

		GridWorld4 = XMMatrixRotationY(0.0f );
		GridWorld4.r[3] = XMVectorSet(0.0f, 0.0f, -0.5f, 1);

		GridWorld5 = XMMatrixRotationY(pi / 2);
		GridWorld5.r[3] = XMVectorSet(0.5f, 0.0f, 0, 1);

		GridWorld6 = XMMatrixRotationY(pi / 2);
		GridWorld6.r[3] = XMVectorSet(-0.5f, 0.0f, 0, 1);*/


		XMVECTOR eye = XMVectorSet(0.5f, 0.0f, -1.0f, 0);
		XMVECTOR at = XMVectorSet(0.0f, 0.0f, 0.0f, 0);
		XMVECTOR up = XMVectorSet(0.0f, 1.0f, 0.0f, 0);

		XMMATRIX CameraMatrix = XMMatrixLookAtLH(eye, at, up);

		float aspect_ratio = 1.0f;
		d3d.GetAspectRatio(aspect_ratio);
		XMMATRIX ProjectionMatrix = XMMatrixPerspectiveFovLH(G_DEGREE_TO_RADIAN_F(65), aspect_ratio, NEAR_PLANE, FAR_PLANE);

		cb.w = XMMatrixIdentity();
		cb.v = CameraMatrix;
		cb.p = ProjectionMatrix;

		D3D11_BUFFER_DESC cbDesc;
		cbDesc.ByteWidth = sizeof(ConstantBuffer);
		cbDesc.Usage = D3D11_USAGE_DEFAULT;
		cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		cbDesc.CPUAccessFlags = 0;
		cbDesc.MiscFlags = 0;
		cbDesc.StructureByteStride = 0;

		cb.lightDir = XMVector3Normalize(XMVectorSet(-1.0f, -1.0f, 2.0f, 0));
		cb.lightColor = XMVectorSet(0.9f, 0.9f, 1.0f, 1.0f);




		D3D11_SUBRESOURCE_DATA cbData = { &cb, 0, 0 };



		creator->CreateBuffer(&cbDesc, &cbData, constantBuffer.GetAddressOf());





		D3D11_SUBRESOURCE_DATA bData = { FSLogo_vertices, 0, 0 };
		CD3D11_BUFFER_DESC bDesc(sizeof(FSLogo_vertices), D3D11_BIND_VERTEX_BUFFER);
		creator->CreateBuffer(&bDesc, &bData, vertexBuffer.GetAddressOf());

		D3D11_SUBRESOURCE_DATA iData = { FSLogo_indices, 0, 0 };
		CD3D11_BUFFER_DESC iDesc(sizeof(FSLogo_indices), D3D11_BIND_INDEX_BUFFER);
		creator->CreateBuffer(&iDesc, &iData, indexBuffer.GetAddressOf());


		// Create Vertex Shader
		UINT compilerFlags = D3DCOMPILE_ENABLE_STRICTNESS;
#if _DEBUG
		compilerFlags |= D3DCOMPILE_DEBUG;
#endif
		Microsoft::WRL::ComPtr<ID3DBlob> vsBlob, errors;
		if (SUCCEEDED(D3DCompile(vertexShaderSource, strlen(vertexShaderSource),
			nullptr, nullptr, nullptr, "main", "vs_4_0", compilerFlags, 0,
			vsBlob.GetAddressOf(), errors.GetAddressOf())))
		{
			creator->CreateVertexShader(vsBlob->GetBufferPointer(),
				vsBlob->GetBufferSize(), nullptr, vertexShader.GetAddressOf());
		}
		else
			std::cout << (char*)errors->GetBufferPointer() << std::endl;
		// Create Pixel Shader
		Microsoft::WRL::ComPtr<ID3DBlob> psBlob; errors.Reset();
		if (SUCCEEDED(D3DCompile(pixelShaderSource, strlen(pixelShaderSource),
			nullptr, nullptr, nullptr, "main", "ps_4_0", compilerFlags, 0,
			psBlob.GetAddressOf(), errors.GetAddressOf())))
		{
			creator->CreatePixelShader(psBlob->GetBufferPointer(),
				psBlob->GetBufferSize(), nullptr, pixelShader.GetAddressOf());
		}
		else
			std::cout << (char*)errors->GetBufferPointer() << std::endl;
		// Create Input Layout
		D3D11_INPUT_ELEMENT_DESC format[] = {
			{
				"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,
				D3D11_APPEND_ALIGNED_ELEMENT,
				D3D11_INPUT_PER_VERTEX_DATA, 0
			},
			{
				"UV", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,
				D3D11_APPEND_ALIGNED_ELEMENT,
				D3D11_INPUT_PER_VERTEX_DATA, 0
			},
			{
				"NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,
				D3D11_APPEND_ALIGNED_ELEMENT,
				D3D11_INPUT_PER_VERTEX_DATA, 0
			}

		};
		creator->CreateInputLayout(format, ARRAYSIZE(format),
			vsBlob->GetBufferPointer(), vsBlob->GetBufferSize(),
			vertexFormat.GetAddressOf());
		// free temporary handle
		creator->Release();
	}
	void Render()
	{
		// grab the context & render target
		ID3D11DeviceContext* con;
		ID3D11RenderTargetView* view;
		ID3D11DepthStencilView* depth;
		d3d.GetImmediateContext((void**)&con);
		d3d.GetRenderTargetView((void**)&view);
		d3d.GetDepthStencilView((void**)&depth);
		// setup the pipeline
		ID3D11RenderTargetView* const views[] = { view };
		con->OMSetRenderTargets(ARRAYSIZE(views), views, depth);
		const UINT strides[] = { sizeof(OBJ_VERT) };
		const UINT offsets[] = { 0 };
		ID3D11Buffer* const buffs[] = { vertexBuffer.Get() };
		/*ID3D11Buffer* const apps[] = { vertexBufferLevel2.Get() };*/
		

			con->IASetVertexBuffers(0, ARRAYSIZE(buffs), buffs, strides, offsets);
			con->IASetIndexBuffer(indexBuffer.Get(), DXGI_FORMAT_R32_UINT, 0);
			con->VSSetShader(vertexShader.Get(), nullptr, 0);
			con->PSSetShader(pixelShader.Get(), nullptr, 0);
			con->IASetInputLayout(vertexFormat.Get());
			con->VSSetConstantBuffers(0, 1, constantBuffer.GetAddressOf());
			con->PSSetConstantBuffers(0, 1, constantBuffer.GetAddressOf());
			con->UpdateSubresource(constantBuffer.Get(), 0, nullptr, &cb, 0, 0);
			// now we can draw
			con->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
			con->DrawIndexed(FSLogo_indexcount, 0, 0);
			/*	for (size_t i = 0; i < LevelRenderer_meshcount; i++)
				{
					con->DrawIndexed()
				}
				*/

		/*cb.w = GridWorld1;
		con->UpdateSubresource(constantBuffer.Get(), 0, nullptr, &cb, 0, 0);
		con->Draw(208, 0);

		cb.w = GridWorld2;
		con->UpdateSubresource(constantBuffer.Get(), 0, nullptr, &cb, 0, 0);
		con->Draw(208, 0);

		cb.w = GridWorld3;
		con->UpdateSubresource(constantBuffer.Get(), 0, nullptr, &cb, 0, 0);
		con->Draw(208, 0);

		cb.w = GridWorld4;
		con->UpdateSubresource(constantBuffer.Get(), 0, nullptr, &cb, 0, 0);
		con->Draw(208, 0);

		cb.w = GridWorld5;
		con->UpdateSubresource(constantBuffer.Get(), 0, nullptr, &cb, 0, 0);
		con->Draw(208, 0);

		cb.w = GridWorld6;
		con->UpdateSubresource(constantBuffer.Get(), 0, nullptr, &cb, 0, 0);
		con->Draw(208, 0);*/

		// release temp handles
		depth->Release();
		view->Release();
		con->Release();
	}
	void Update() {
		auto now = std::chrono::steady_clock::now();
		float timeElapsed = std::chrono::duration_cast<std::chrono::microseconds>(now - previousFrame).count();
		timeElapsed /= 1000000; //scales it down to seconds
		POINT mPos;
		GetCursorPos(&mPos);

		XMMATRIX cameraControl = cb.v;
		cameraControl = XMMatrixInverse(nullptr, cameraControl);
		float cSpeed = 5.0f;
		float cRotationSpeed = 0.001f;
		float cameraChange = cSpeed * timeElapsed;
		bool cameraMove = false;

		// you can put a character in single-quotes to get the ascii-code automatically
		// if (GetKeyState('W') & 0x01) // "& 0x01" will check for key-presses only, instead of any key-down condition 

		//w
		if (GetKeyState(0x57) & 0x8000) {
			cameraControl.r[3] += (cameraControl.r[2] * cameraChange);
		}
		//s
		if (GetKeyState(0x53) & 0x8000) {
			cameraControl.r[3] -= (cameraControl.r[2] * cameraChange);
		}
		//d
		if (GetKeyState(0x44) & 0x8000) {
			cameraControl.r[3] += (cameraControl.r[0] * cameraChange);
		}
		//a
		if (GetKeyState(0x41) & 0x8000) {
			cameraControl.r[3] -= (cameraControl.r[0] * cameraChange);
		}
		//space
		if (GetKeyState(VK_SPACE) & 0x8000)
		{
			cameraControl.r[3] += (cameraControl.r[1] * cameraChange);
		}
		//shift
		if (GetKeyState(VK_SHIFT) & 0x8000) {
			cameraControl.r[3] -= (cameraControl.r[1] * cameraChange);
		}

		//hold down right click so you can close the program with the freehand mouse
		if (GetKeyState(VK_RBUTTON) & 0x8000) {
			std::vector<float> direction;
			//pushing the difference between current mouse pos and previous mouse position
			direction.push_back(mPos.x - previousMousePos.x);
			direction.push_back(mPos.y - previousMousePos.y);
			for (size_t i = 0; i < direction.size(); i++)
			{
				direction[i] *= timeElapsed;
			}
			XMVECTOR pos = cameraControl.r[3];
			cameraControl.r[3] = XMVectorSet(0, 0, 0, 1);
			cameraControl = XMMatrixMultiply(XMMatrixRotationX(direction[1]), cameraControl);
			cameraControl = XMMatrixMultiply(cameraControl, XMMatrixRotationY(direction[0]));
			cameraControl.r[3] = pos;
		}


		float ar = 1;
		d3d.GetAspectRatio(ar);
		cb.p = XMMatrixPerspectiveFovLH(65, ar, NEAR_PLANE, FAR_PLANE);
		cb.v = XMMatrixInverse(nullptr, cameraControl);

		previousFrame = now;
		previousMousePos = mPos;
	}


	~Renderer()
	{
		// ComPtr will auto release so nothing to do here 
	}
};

