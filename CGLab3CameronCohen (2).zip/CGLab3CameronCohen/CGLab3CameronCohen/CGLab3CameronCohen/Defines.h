#pragma once
#define FOV 90
#define _width 500
#define _height 500
#define ASPECTRATIO (_width / _height)
#define NEARPLANE .1
#define FARPLANE 10.0
#define _totalPixels (_width * _height)
#define PI 3.14159


struct VERTEX { float position[4] = {0, 0, 0, 1}; unsigned int color = 0xFFFFFFFF; };

struct PIXEL { float position[4]; unsigned int color; };

struct MATRIX { float matrix[4][4] = { {0,}, }; };

struct VER_3D { float x, y, z = 0; };

struct VER_2D { float x, y; };

struct COLOR { unsigned int x, y, z; };

typedef VER_3D BARRYCOORD;