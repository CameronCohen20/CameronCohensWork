#pragma once
#include "Defines.h"
#include <cmath>
#include "Math.h"
#include "Shaders.h"

unsigned int Raster[_totalPixels] = { 0, };

unsigned int ConvDim(unsigned int x, unsigned int y, unsigned int width);

void PlotPixel(unsigned int positionX, unsigned int positionY, unsigned int color);

unsigned int Lerp(unsigned int sValue, unsigned int dValue);

unsigned int FloatLerp(float a, float b, float r);

void ParametricLine(unsigned int startX, unsigned int startY, unsigned int endX, unsigned int endY);  //long version that doesnt use any vertex

void ParametricLine(VERTEX sVert, VERTEX eVert);





unsigned int ConvDim(unsigned int x, unsigned int y, unsigned int width) {
	return y * width + x;
}

void PlotPixel(unsigned int positionX, unsigned int positionY, unsigned int color) {
	unsigned int position = ConvDim(positionX, positionY, _width);

	if (Raster[position] != color && color != 0) //to see if the position doesnt have a color or a color
	{
		Raster[position] = color;
		//unsigned int byte1 = 0xFF000000 & Raster[position]; //white and where the position is

		//if (color < 0xFF000000 && color > 0 && byte1 > 0)
		//{
		//	Raster[position] = (Lerp(Raster[position], color)); //Lerps the current position and makes it the color
		//}
		//else
		//{
		//	Raster[position] = color; //makes the current position the color
		//}
	}
}

unsigned int Lerp(unsigned int sValue, unsigned int dValue) {
	unsigned int source[] = { 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF }; //source value with red, green, blue, and aplha
	unsigned int destination[] = { 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF }; //destination value with red, green, blue, and alpha

	for (size_t i = 0; i < 4; i++)
	{
		source[i] = source[i] & sValue;

		destination[i] = destination[i] & dValue;
	}

	int rValue = source[0];
	unsigned int color = 0x00000000;

	for (size_t i = 0; i < 4; i++)
	{
		color += (destination[i] - source[i]) * rValue / 0xFF000000 + source[i]; //(B - A) * R / (derived from alpha) + A
	}

	return color;
}

unsigned int FloatLerp(float a, float b, float r) {
	return (b - a) * r + a;
}

void ParametricLine(unsigned int startX, unsigned int startY, unsigned int endX, unsigned int endY) {
	float deltaX = 0;
	float deltaY = 0;

	deltaX = float(startX) - float(endX);
	deltaY = float(startY) - float(endY);

	unsigned int color = 0x00FF0000; //green

	if (deltaX != 0 || deltaY != 0)
	{
		if (abs(deltaX) >= abs(deltaY))
		{
			float currY = float(startY);

			for (unsigned int i = startX; i <= endX; i++)
			{
				float r = (i - startX) / deltaX;

				currY = FloatLerp(float(startY), float(endY), abs(r));

				PlotPixel(i, unsigned int(floor(currY + .5f)), color);
			}
		}
		else
		{
			float currX = float(startX);

			for (unsigned int i = startY; i <= endY; i++)
			{
				float r2 = (i - startY) / deltaY;

				currX = FloatLerp(float(startX), float(endX), abs(r2));

				PlotPixel(unsigned int(floor(currX + .5f)), i, color);
			}
		}

	}
	else
	{

		if (deltaX == 0)
		{
			for (unsigned int i = startY; i <= endY; i++)
			{
				PlotPixel(startX, i, color);
			}
		}
		else if (deltaY == 0)
		{
			for (unsigned int i = startX; i <= endX; i++)
			{
				PlotPixel(i, startY, color);
			}
		}
	}
}

inline void ParametricLine(VERTEX sVert, VERTEX eVert)
{
	VERTEX vertStart = sVert;
	VERTEX vertEnd = eVert;

	if (VertexShader)
	{
		VertexShader(vertStart);
		VertexShader(vertEnd);
	}

	VERTEX aPos = NDCtoScreen(vertStart);
	VERTEX bPos = NDCtoScreen(vertEnd);

	float deltaX = fabsf(bPos.position[0] - aPos.position[0]);
	float deltaY = fabsf(bPos.position[1] - aPos.position[1]);

	unsigned int pixels = fmaxf(deltaX, deltaY);
	for (size_t i = 0; i < pixels; i++)
	{
		float r = i / static_cast<float>(pixels); //convert to float

		float x = (bPos.position[0] - aPos.position[0]) * r + aPos.position[0];

		float y = (bPos.position[1] - aPos.position[1]) * r + aPos.position[1];

		PlotPixel(x + .5f, y + .5f, aPos.color);
	}
}


