#pragma once
#include "defines.h"
#include "shaders.h"
#include <corecrt_math.h>
#include "math.h"

unsigned int Raster[_TOTALPIXELS] = { 0, };

void PlotPixel(unsigned int x, unsigned int y, unsigned int color);
unsigned int ConvDim(unsigned int x, unsigned int y, unsigned int width);
void ParametricLine(VERTEX a, VERTEX b);
BARYCOORD Barycentric(VERTEX a, VERTEX b, VERTEX c, VERTEX r);
float ImplicitLine(VERTEX a, VERTEX b, VERTEX r);
void TriangleFill(VERTEX a, VERTEX b, VERTEX c);

inline void PlotPixel(unsigned int x, unsigned int y, unsigned int color)
{
	unsigned int _pos = ConvDim(x, y, _WIDTH);
		if (Raster[_pos] != color && color != 0)
		{
			Raster[_pos] = color;
		}
}

unsigned int ConvDim(unsigned  int x, unsigned int y, unsigned int width) {
	return y * width + x;
}

inline void ParametricLine(VERTEX a, VERTEX b)
{
	VERTEX vertStart = a;
	VERTEX vertEnd = b;

	if (VertexShader)
	{
		VertexShader(vertStart);
		VertexShader(vertEnd);
	}

	VERTEX x = NDCtoScreen(vertStart);
	VERTEX y = NDCtoScreen(vertEnd);

	float deltaX = fabsf(b.position[0] - a.position[0]);
	float deltaY = fabsf(b.position[1] - a.position[1]);


	int pixels = static_cast<int>(fmaxf(deltaX, deltaY));

	for (size_t i = 0; i < pixels; ++i)
	{

		float R = i / static_cast<float>(pixels);

		float x = (b.position[0] - a.position[0]) * R + a.position[0];

		float y = (b.position[1] - a.position[1]) * R + a.position[1];

		PlotPixel(static_cast<int>(x + 0.5f), static_cast<int>(y + 0.5f), a.color);
	}
}

inline BARYCOORD Barycentric(VERTEX a, VERTEX b, VERTEX c, VERTEX r)
{
	float maxA = ImplicitLine(b, c, a);

	float maxB = ImplicitLine(a, c, b);

	float maxC = ImplicitLine(b, a, c);

	float minA = ImplicitLine(b, c, r);

	float minB = ImplicitLine(a, c, r);

	float minC = ImplicitLine(b, a, r);

	return { minA / maxA, minB / maxB, minC / maxC };
}

inline float ImplicitLine(VERTEX a, VERTEX b, VERTEX r)
{
	return (a.position[1] - b.position[1]) * r.position[0] + (b.position[0] - a.position[0]) * r.position[1] + a.position[0] * b.position[1] - a.position[1] * b.position[0];;
}

inline void TriangleFill(VERTEX x, VERTEX y, VERTEX z)
{
	VERTEX xCopy = x;
	VERTEX yCopy = y;
	VERTEX zCopy = z;

	if (VertexShader)
	{
		VertexShader(xCopy);
		VertexShader(yCopy);
		VertexShader(zCopy);
	}

	VERTEX a = NDCtoScreen(xCopy); //sets ndc for
	VERTEX b = NDCtoScreen(yCopy);
	VERTEX c = NDCtoScreen(zCopy);

	unsigned int color = a.color;

	for (size_t y = 0; y < _HEIGHT; y++)
	{
		for (size_t x = 0; x < _WIDTH; x++)
		{
			VERTEX r = {
				{x,y,0,0}, 0xFF000000
			};

			auto barycentric = Barycentric(a, b, c, r);

			if (barycentric.x >= 0 && barycentric.x <= 1 && barycentric.y >= 0 && barycentric.y <= 1 && barycentric.z >= 0 && barycentric.z <= 1)
			{
				color = Berp({ a.color, b.color, c.color }, barycentric);

				PlotPixel(x, y, color);
			}
		}
	}
}


