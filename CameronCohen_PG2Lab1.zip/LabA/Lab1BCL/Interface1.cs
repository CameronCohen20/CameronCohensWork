﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1BCL
{
      public interface IVehicle
    {
        int Year { get; set; }
        string Make { get; set; }
        string Model { get; set; }
        int Passengers { get; set; }

        string Display();
    }
    public class Minivan : Motorized
    {
        
        int SlidingDoors { get; set; }

        public Minivan(int year, string make, string model, int passengers, int slidingDoors) : base(year, make, model, passengers)
        {
            SlidingDoors = slidingDoors;
        }
        public override string Display()
        {
            string display = $"{Year} {Make} - {Model} {Passengers} {SlidingDoors}";
            return display;
        }
    }

    public class Truck : Motorized
    {
        int Capacity { get; set; }
        public Truck(int year, string make, string model, int passengers, int capacity) : base(year, make, model, passengers)
        {
            Capacity = capacity;
        }
        public override string Display()
        {
            string display = $"{Year} {Make} - {Model} {Passengers} {Capacity}";
            return display;
        }
    }
}
