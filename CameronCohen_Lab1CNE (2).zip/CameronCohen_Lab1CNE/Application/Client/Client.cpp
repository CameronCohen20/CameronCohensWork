#define _CRT_SECURE_NO_WARNINGS                 
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include "Client.h"

int Client::init(uint16_t port, char* address)
{

	sockaddr_in serverAddy;

	serverAddy.sin_family = AF_INET;
	serverAddy.sin_addr.S_un.S_addr = inet_addr(address);
	serverAddy.sin_port = htons(port);

	int result = connect(cSocket, (SOCKADDR*)&serverAddy,sizeof(serverAddy));

	if (result == SOCKET_ERROR)
	{
		if (WSAGetLastError() == SHUTDOWN) 
		{
			return SHUTDOWN;
		}
		return CONNECT_ERROR;
	}

	if (inet_addr(address) == INADDR_NONE)
	{
		return ADDRESS_ERROR;
	}

	cSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (cSocket == INVALID_SOCKET)
	{
		return SOCKET_ERROR;
	}

	return SUCCESS;
}
int Client::readMessage(char* buffer, int32_t size)
{
	int messageSize = 0;
	int bytesRecieved = 0;

	int temp = recv(cSocket, (char*)&messageSize, 1, 0);

	if (temp == SOCKET_ERROR || temp == 0)
	{
		if (WSAGetLastError() == SHUTDOWN) 
		{
			return SHUTDOWN;
		}

		return DISCONNECT;
	}

	

	while (bytesRecieved < messageSize)
	{
		int result = recv(cSocket, buffer + bytesRecieved, messageSize - bytesRecieved, 0);

		if (result == SOCKET_ERROR || result == 0)
		{
			if (WSAGetLastError() == SHUTDOWN) 
			{
				return SHUTDOWN;
			}
			return DISCONNECT;
		}
		else 
		{
			bytesRecieved += result;
		}
	}

	if (bytesRecieved > size) 
	{
		return PARAMETER_ERROR;
	}

	return SUCCESS;
}
int Client::sendMessage(char* data, int32_t length)
{
	int result;
	uint8_t messageLength = length;

	//Size
	result = send(cSocket, (const char*)&messageLength, 1, 0);

	if (length < 0 || length > 255)
	{
		return PARAMETER_ERROR;
	}
	int bytesGone = 0;

	//Sending Message
	while (bytesGone < length)
	{
		result = send(cSocket, (const char*)data + bytesGone, length - bytesGone, 0);

		if (result <= 0)
		{
			if (WSAGetLastError() == SHUTDOWN)
			{
				return SHUTDOWN;
			}

			return DISCONNECT;
		}
		bytesGone += result;
	}


	return SUCCESS;
}
void Client::stop()
{
	shutdown(cSocket, SD_BOTH);
	close(cSocket);
}