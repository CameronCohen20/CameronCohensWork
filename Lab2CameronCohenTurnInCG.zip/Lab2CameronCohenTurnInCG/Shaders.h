#pragma once
#include "Defines.h"
#include "Math.h"

void (*VertexShader)(VERTEX&) = 0;
void (*PixelShader)(PIXEL) = 0;


//makes world, camera, and projection matrix
MATRIX SV_WorldMatrix;
MATRIX SV_CameraMatrix;
MATRIX SV_ProjectionMatrix;


void VS_World(VERTEX& multiplyMe) {
	multiplyMe = MultiplyVertexByMatrix(multiplyMe, SV_WorldMatrix);
}

//infrastructure for 3D rendering
void VS_3DPipeLine(VERTEX& multiplyMe) {
	VS_World(multiplyMe);


	multiplyMe = MultiplyVertexByMatrix(multiplyMe, OrthgonalInverseMatrix(SV_CameraMatrix));
	multiplyMe = MultiplyVertexByMatrix(multiplyMe, SV_ProjectionMatrix);


	for (size_t i = 0; i < 3; i++)
	{
		multiplyMe.position[i] /= multiplyMe.position[3];
	}
}

void VS_MoveRight(VERTEX &changeMe) {
	VS_World(changeMe);
}


//void PS_White(PIXEL& makeWhite) {
//	//makeWhite = 0xFFFFFFFF;
//}
