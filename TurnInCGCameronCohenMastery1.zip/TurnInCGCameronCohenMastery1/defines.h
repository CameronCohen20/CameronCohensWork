#pragma once
#include "RasterSurface.h"

#define _WIDTH 500
#define _HEIGHT 500
#define _TOTALPIXELS ((_WIDTH) * (_HEIGHT))

struct VER_2D { float x, y; };

struct VERTEX_2D { VER_2D position; unsigned int color; };