#include "Defines.h"

int recMessage(SOCKET s, char* buffer, int len, int flags)
{
    int total = 0;

    do
    {
        int result = recv(s, buffer + total, len - total, flags);
        if (result < 1)
            return result;
        else
            total += result;
    } while (total < len);

    return total;
}

int sendMessage(SOCKET s, const char* data, int len)
{
    int bytesSent = 0;

    while (bytesSent < len)
    {
        int result = send(s, (const char*)data + bytesSent, len - bytesSent, 0);

        if (result <= 0)
            return result;
        bytesSent += result;
    }
    return 0;
}
