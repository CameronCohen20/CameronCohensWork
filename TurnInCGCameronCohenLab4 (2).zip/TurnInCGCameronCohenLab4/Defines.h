#pragma once
#define FOV 90
#define _WIDTH 500
#define _HEIGHT 500
#define ASPECTRATIO (_WIDTH / _HEIGHT)
#define NEARPLANE .1
#define FARPLANE 50.0
#define _totalPixels (_WIDTH * _HEIGHT)
#define PI 3.14159


struct VERTEX { float position[4] = {0, 0, 0, 1}; unsigned int color = 0xFFFFFFFF; };

struct PIXEL { float position[4]; unsigned int color; };

struct MATRIX { float matrix[4][4] = { {0,}, }; };