#include "PathSearch.h"




//
namespace fullsail_ai { namespace algorithms {

	PathSearch::PathSearch()
	{
		tileMap = nullptr;
	}

	PathSearch::~PathSearch()
	{
	}

	void PathSearch::initialize(TileMap* _tileMap)
	{
		tileMap = _tileMap;
		for (size_t i = 0; i < _tileMap->getRowCount(); i++)
		{
			for (size_t j = 0; j < _tileMap->getColumnCount(); j++)
			{
				if (_tileMap->getTile(i, j)->getWeight() == 0)
				{
					continue;
				}
				SearchNode* temp = new SearchNode();
				temp->tile = _tileMap->getTile(i, j);
				nodes.insert(std::make_pair(_tileMap->getTile(i, j), temp));
			}
		}




		for (size_t i = 0; i < _tileMap->getRowCount(); i++)
		{
			for (size_t j = 0; j < _tileMap->getColumnCount(); j++)
			{
				Tile* _temp = _tileMap->getTile(i, j);
				if (_temp->getWeight() == 0)
				{
					continue;
				}


				SearchNode* _current = nodes[_temp];

				if (i % 2 == 0)
				{
					if (nodes[_tileMap->getTile(i - 1, j - 1)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i - 1, j - 1)]);
					}
					if (nodes[_tileMap->getTile(i, j + 1)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i, j + 1)]);
					}
					if (nodes[_tileMap->getTile(i - 1, j)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i - 1, j)]);
					}
					if (nodes[_tileMap->getTile(i + 1, j)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i + 1, j)]);
					}
					if (nodes[_tileMap->getTile(i, j - 1)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i, j - 1)]);
					}
					if (nodes[_tileMap->getTile(i + 1, j - 1)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i + 1, j - 1)]);
					}
				}

				else
				{
					if (nodes[_tileMap->getTile(i, j + 1)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i, j + 1)]);
					}
					if (nodes[_tileMap->getTile(i - 1, j)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i - 1, j)]);
					}
					if (nodes[_tileMap->getTile(i, j - 1)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i, j - 1)]);
					}
					if (nodes[_tileMap->getTile(i + 1, j)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i + 1, j)]);
					}
					if (nodes[_tileMap->getTile(i - 1, j + 1)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i - 1, j + 1)]);
					}
					if (nodes[_tileMap->getTile(i + 1, j + 1)] != nullptr)
					{
						_current->neighbors.push_back(nodes[_tileMap->getTile(i + 1, j + 1)]);
					}

				}
			}
		}
	}

	void PathSearch::enter(int startRow, int startColumn, int goalRow, int goalColumn)
	{
		start = nodes[tileMap->getTile(startRow, startColumn)];
		goal = nodes[tileMap->getTile(goalRow, goalColumn)];

		PlannerNode* st = new PlannerNode();

		st->searchNode = start;
		st->givenc = 0;
		st->heurcost = distance(start, goal);
		st->finalc = st->givenc + st->heurcost * 1.2f;
		st->parent = nullptr;


		open.push(st);
		visited[start] = open.front();
	}

	void PathSearch::update(long timeslice)
	{
		while (!open.empty())
		{
			PlannerNode* current = open.front();
			open.pop();
			if (current->searchNode->tile == goal->tile)
			{
				path.clear();
				while (current != nullptr)
				{
					path.push_back(current->searchNode->tile);
					if (current->parent != nullptr)
					{
						current->searchNode->tile->addLineTo(current->parent->searchNode->tile, 0xffff0000);
					}
					current = current->parent;
				}
				over = true;
				return;
			}
			for (size_t i = 0; i < current->searchNode->neighbors.size(); i++)
			{
				SearchNode* succ = current->searchNode->neighbors[i];
				float tgc = current->givenc + current->searchNode->neighbors[i]->tile->getWeight();
				if (visited[succ] != NULL)
				{
					PlannerNode* node = visited[succ];
					if (tgc < node->givenc)
					{
						open.remove(node);
						node->parent = current;
						node->givenc = tgc;
						node->finalc = node->givenc + node->heurcost * 1.2f;
						visited[succ] = node;
						open.push(node);
					}
				}
				else
				{
					PlannerNode* node = new PlannerNode();
					node->searchNode = succ;
					node->parent = current;
					node->givenc = tgc;
					node->heurcost = distance(succ, goal);
					node->finalc = node->givenc + node->heurcost * 1.2f;
					open.push(node);
					visited[succ] = node;
				}
			}
		}


	} 

	

	float PathSearch::distance(SearchNode* s, SearchNode* g)
	{
		float x = g->tile->getRow() - s->tile->getRow();

		float y = g->tile->getColumn() - s->tile->getColumn();

		return std::sqrt(x * x + y * y);

	}

	void PathSearch::exit()
	{
		open.clear();

		visited.clear();

		over = false;
	}

	void PathSearch::shutdown()
	{
		nodes.clear();
	}

	bool PathSearch::isDone() const
	{
		return over;
	}

	std::vector<Tile const*> const PathSearch::getSolution() const
	{
		return path;
	}
}}  // namespace fullsail_ai::algorithms

