#pragma once
#include <WinSock2.h>
#include <string>
#include <iostream>
#include <WS2tcpip.h>
#include "Defines.h"
#include <map>


using namespace std;

class ChatClient
{
	SOCKET connectSocket;
	unsigned int id;

	string username;

	//Threading stuff

public:

	//Default
	ChatClient();

	//Establishes a connection with the server
	bool init(string ip_address, uint16_t port);

	//Receives data from the server, parses, it, responds accordingly
	bool run(void);

	SOCKET getSocket();

	string recServerMessage();

};

