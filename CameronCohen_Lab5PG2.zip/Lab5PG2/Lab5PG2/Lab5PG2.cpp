// Lab5PG2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <time.h>
#include <vector>


enum class Superpowers
{
    Strength,
    Speed,
    Invisibility,
    Telekinesis,
    Flight,
};
//factorial
long factorial(int n)
{
    if (n <= 1)
    {
        return 1;
    }
    long value = factorial(n - 1);
    return n * value;
}
//vector method
std::vector<char> letterGrades = { 'A', 'B', 'C', 'D', 'F' };
char Grade(int g)
{
    if (g >= 90)
    {
        return letterGrades[0];
    }
    else if (g < 90 && g >= 80)
    {
        return letterGrades[1];
    }
    else if (g < 80 && g >= 73)
    {
        return letterGrades[2];
    }
    else if (g < 73 && g >= 70)
    {
        return letterGrades[3];
    }
    else if (g < 70)
    {
        return letterGrades[4];
    }
}

int main()
{
    //basic output
    std::cout << "Batman is the best superhero!\n";

    //variables
    bool iBool = 0;
    int iInt = 4;
    float iFloat = 5;
    double iDouble = 2;
    char iChar = 'A';

    //initialize and print each one
    std::cout << "Size of iBool: " << sizeof(iBool) << '\n';
    std::cout << "Size of iInt: " << sizeof(iInt) << '\n';
    std::cout << "Size of iDouble: " << sizeof(iDouble) << '\n';
    std::cout << "Size of iFloat: " << sizeof(iFloat) << '\n';
    std::cout << "Size of iChar: " << sizeof(iChar) << '\n';

    //create an array of Floats and Char and initialize it
    char name[7] = "Batman";
    std::cout << name << '\n';
    float name2[7] = {};
    std::cout << name2 << '\n';

    //loops
    for (size_t i = 0; i <= 100; i++)
    {
        if (i%2 == 0)
        {
            std::cout << i << '\n';
        }
    }
    std::cout << "------------------------------------------------------------------------------------------------------------------------" << '\n';

    //while loop
    int count = 0;
    while (count <= 1000)
    {
        std::cout << count << '\n';
        count++;
    }
    std::cout << "------------------------------------------------------------------------------------------------------------------------" << '\n';

    //do while loop
    int count1 = 0;
    do
    {
        std::cout << count1 << '\n';
        count1++;
    } while (count1 <= 1000);
    std::cout << "------------------------------------------------------------------------------------------------------------------------" << '\n';

    //Random Number generator
    srand((unsigned)time(0));
    int randomNumber;
    for (int index = 0; index < 10; index++)
    {
        randomNumber = (rand() % 100) + 1;
       
        if (randomNumber >= 90)
        {
            std::cout << randomNumber << " A " << '\n';
        }
        else if ((randomNumber < 89) && (randomNumber >= 80))
        {
            std::cout << randomNumber << " B " << '\n';
        }
        else if ((randomNumber < 79) && (randomNumber >= 73))
        {
            std::cout << randomNumber << " C " << '\n';
        }
        else if ((randomNumber < 72) && (randomNumber >= 70))
        {
            std::cout << randomNumber << " D " << '\n';
        }
        else if (randomNumber <= 69)
        {
            std::cout << randomNumber << " F " << '\n';
        }

    }
    std::cout << "------------------------------------------------------------------------------------------------------------------------" << '\n';


    //Switch
    srand((unsigned)time(0));
    int result = 1 + (rand() % 6);
    switch (result)
    {
    case 1:
        std::cout << "0: The Bat" << '\n';
        break;
    case 2:
        std::cout << "1: Batman" << '\n';
        break;
    case 3:
        std::cout << "2: Bats" << '\n';
        break;
    case 4:
        std::cout << "3: The Dark Knight" << '\n';
        break;
    case 5:
        std::cout << "4: Nightwing" << '\n';
        break;
    case 6:
        std::cout << "5: Bruce" << '\n';
        break;
    default:
        break;
    }
    std::cout << "------------------------------------------------------------------------------------------------------------------------" << '\n';

    //Enums
    //srand((unsigned)time(0));
    //Superpowers superPowers = new rand


    //Methods
    for (size_t i = 1; i < 16; i++)
    {
        std::cout << "The Factorial of  " << i << ": " << factorial(i) << '\n';
    }
    std::cout << "------------------------------------------------------------------------------------------------------------------------" << '\n';


    //Vectors
    for (size_t i = 0; i < 10; i++)
    {
        int val = rand() % 100;
        std::cout << "Your grade: " << Grade(val) << ": " << val << '\n';
    }
}
