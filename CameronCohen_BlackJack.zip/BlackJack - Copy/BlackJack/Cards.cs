﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    public class Cards
    {
        public string Value { get; set; }
        public string Suit { get; set; }


        public Cards(string value, string suit)
        {
            this.Value = value;
            this.Suit = suit;

        }

        public static string[] ValidSuit()
        {
            string[] suit = new string[4];
            suit[0] = "Hearts";
            suit[1] = "Spades";
            suit[2] = "Diamonds";
            suit[3] = "Clubs";

            return suit;
        }

        public static string[] ValidValue()
        {
            string[] value = new string[13];
            value[0] = "Ace";
            for (int i = 2; i <= 10; i++)
            {
                value[i - 1] = i.ToString();
            }
            value[10] = "Jack";
            value[11] = "Queen";
            value[12] = "King";
            return value;
        }

        public void Display(bool isHidden = false)
        {
            Console.BackgroundColor = ConsoleColor.White;
            if (isHidden)
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("Hidden");
            }
            else if ("Hearts" == Suit)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"♥ {Value} ♥");
            }
            else if ("Clubs" == Suit)
            {
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine($"♣ {Value} ♣");
            }
            else if ("Spades" == Suit)
            {
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine($"♠ {Value} ♠");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"♦ {Value} ♦");
            }
            Console.ResetColor();
        }
    }
}
