﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4PG2
{
   public class PG2Queue<T>
    {
        //front of the queue and the back od the queue
         Node<T> front;
         Node<T> back;

        //Count should keep track of each item in the list
        private int count = 0;
        public int Count { get { return count; } }

        //create a Enqueue that will add to the end of the list
        public void Enqueue(T data)
        {
            Node<T> end = new Node<T>(data, null);

            if (count == 0) //checks if count is at 0
            {
                front = end;
            }
            else //move to the end of the list
            {
                back.Next = end;
            }
            back = end;
            count++;
        }

        //create a dequeue that will remove items from the end of list
        public T Dequeue()
        {
            if (count == 1)
            {
                front = null;
                back = null;
                Node<T> a = front;
                count--;
                return a.Data;
            }
            else if (front != null)
            {
                Node<T> b = front;
                front = front.Next;
                count--;
                return b.Data;
            }
            return default;
        }

        //create a peek that will look at the item in the front of the list
        public T Peek()
        {
            return front.Data;
        }

        //create a reverse that will reverse the list
        public void Reverse()
        {
            Node<T> temp1 = null;
            Node<T> temp2 = front;
            Node<T> temp3 = null;

            while (temp2 != null)
            {
                temp3 = temp2.Next;
                temp2.Next = temp1;
                temp1 = temp2;
                temp2 = temp3;
            }
            front = temp1;
        }

        public string Print()
        {
            string print = string.Empty;
            Node<T> x = front;
            while (x != null)
            {
                print += $"{x.Data}";
                x = x.Next;
            }
            return print;
        }
    }
}
