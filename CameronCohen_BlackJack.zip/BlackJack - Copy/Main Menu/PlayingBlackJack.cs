﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlackJack;
namespace Main_Menu
{
    public static class PlayingBlackJack
    {
        public static void Deal(Deck deck, Hand player, Hand dealer)
        {
            Hit(deck, player);
            
            Hit(deck, dealer);
        }

        public static void Hit(Deck deck, Hand target)
        {
            Cards card = deck.DrawCard();
            target.AddCard(card);
        }

        public static bool CheckScore(Hand target, bool isDealer = false)
        {
            if (target.Score > 21)
            {
                return false;
            }

            if (isDealer && target.Score >= 17)
            {
                return false;
            }
            return true;
        }
    }
}
