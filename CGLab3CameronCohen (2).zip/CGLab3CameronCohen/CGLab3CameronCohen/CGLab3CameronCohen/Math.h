#pragma once
#include "Defines.h"
#include <corecrt_math.h>
static VERTEX MultiplyVertexByMatrix(VERTEX vert, MATRIX m);
static VERTEX NDCtoScreen(VERTEX vert);
static MATRIX BuildRotationMatrixY(float rad);
static MATRIX BuildRotationMatrixX(float rad);
//static MATRIX BuildRotationMatrixZ(float rad);
static MATRIX OrthgonalInverseMatrix(MATRIX mat);
static MATRIX MultiplyMatrixByMatrix(MATRIX m, MATRIX m2);
static float Berp(float a, float b, float c, BARRYCOORD coord);
static unsigned int BerpColor(COLOR colors, BARRYCOORD coord);



static VERTEX NDCtoScreen(VERTEX vert) {
	VERTEX aPos;

	aPos.color = vert.color;
	aPos.position[0] = (vert.position[0] + 1) * (_width / 2); //coord conversion 1 + x * width / 2
	aPos.position[1] = (-vert.position[1] + 1) * (_height / 2); //coord conversion 1 - y * height / 2

	return aPos;
}

MATRIX BuildRotationMatrixY(float rad) {
	MATRIX m;

	m.matrix[0][0] = cosf(rad);
	m.matrix[2][0] = -sinf(rad);
	m.matrix[0][2] = sinf(rad);
	m.matrix[2][2] = cosf(rad);
	m.matrix[1][1] = 1;
	m.matrix[3][3] = 1;

	return m;
}

VERTEX MultiplyVertexByMatrix(VERTEX vert, MATRIX m) {
	VERTEX temp;

	temp.color = vert.color;

	temp.position[3] = 0;

	for (size_t i = 0; i < 4; i++)
	{
		for (size_t j = 0; j < 4; j++)
		{
			temp.position[j] += vert.position[i] * m.matrix[i][j];
		}
	}

	return temp;
}

static MATRIX BuildRotationMatrixX(float rad) {
	MATRIX m;

	m.matrix[1][1] = cosf(rad);
	m.matrix[1][2] = -sinf(rad);
	m.matrix[2][1] = sinf(rad);
	m.matrix[2][2] = cosf(rad);
	m.matrix[0][0] = 1;
	m.matrix[3][3] = 1;
	return m;
}
//
//static MATRIX BuildRotationMatrixZ(float rad) {
//	MATRIX m;
//	m.matrix[0][0] = cosf(rad);
//	m.matrix[0][1] = -sinf(rad);
//	m.matrix[1][0] = sinf(rad);
//	m.matrix[1][1] = cosf(rad);
//	m.matrix[2][2] = 1;
//	m.matrix[3][3] = 1;
//	return m;
//}

static MATRIX OrthgonalInverseMatrix(MATRIX mat) {
	MATRIX m = mat;
	VERTEX temp;

	for (size_t i = 0; i < 3; i++)
	{
		for (size_t j = 0; j < 3; j++)
		{
			if (i != j)
			{
				float temp = mat.matrix[i][j];

				m.matrix[i][j] = mat.matrix[j][i];
				m.matrix[j][i] = temp;
			}
		}
	}


	temp.position[3] = 0;

	for (size_t i = 0; i < 3; i++)
	{
		for (size_t j = 0; j < 3; j++)
		{
			temp.position[j] += mat.matrix[3][i] * mat.matrix[i][j];
		}
	}

	for (size_t i = 0; i < 3; i++)
	{
		temp.position[i] *= -1;

		m.matrix[3][i] = temp.position[i];
	}

	return m;
}

inline MATRIX MultiplyMatrixByMatrix(MATRIX m, MATRIX m2)
{
	MATRIX mat;

	for (size_t i = 0; i < 4; i++)
	{
		for (size_t j = 0; j < 4; j++)
		{
			for (size_t k = 0; k < 4; k++)
			{
				mat.matrix[i][j] += m.matrix[i][k] * m2.matrix[k][j];
			}
		}
	}
	return mat;
}

inline float Berp(float a, float b, float c, BARRYCOORD coord)
{
	return a * coord.x + b * coord.y + c * coord.z;
}

inline unsigned int BerpColor(COLOR colors, BARRYCOORD coord)
{
	int aR = (static_cast<int>(colors.x) & 0xFF000000) >> 24;
	int aG = (static_cast<int>(colors.x) & 0x00FF0000) >> 16;
	int aB = (static_cast<int>(colors.x) & 0x0000FF00) >> 8;
	int aA = (static_cast<int>(colors.x) & 0x000000FF);

	int bR = (static_cast<int>(colors.y) & 0xFF000000) >> 24;
	int bG = (static_cast<int>(colors.y) & 0x00FF0000) >> 16;
	int bB = (static_cast<int>(colors.y) & 0x0000FF00) >> 8;
	int bA = (static_cast<int>(colors.y) & 0x000000FF);

	int cR = (static_cast<int>(colors.z) & 0xFF000000) >> 24;
	int cG = (static_cast<int>(colors.z) & 0x00FF0000) >> 16;
	int cB = (static_cast<int>(colors.z) & 0x0000FF00) >> 8;
	int cA = (static_cast<int>(colors.z) & 0x000000FF);

	unsigned int fR = aR * coord.x + bR * coord.y + cR * coord.z;
	unsigned int fG = aG * coord.x + bG * coord.y + cG * coord.z;
	unsigned int fB = aB * coord.x + bB * coord.y + cB * coord.z;
	unsigned int fA = aA * coord.x + bA * coord.y + cA * coord.z;

	return (fR << 24) | (fG << 16) | (fB << 8) | (fA);
}

