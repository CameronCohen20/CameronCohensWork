﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlackJack;

namespace Main_Menu
{
    class Menu
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Welcome to BlackJack!");
            Deck deck1 = new Deck();
            int menuChoice = 0;
            string[] item = new string[] { "1.Play BlackJack", "2.Shuffle and Show Deck", "3.Exit" };

            bool check = true;
            while (check)
            {
                ReadChoice("You didn't make a valid selection.", item, out menuChoice);
                if (menuChoice == 1)
                {
                    Hand dealer = new Hand();
                    Hand player = new Hand();
                    deck1.Shuffle();
                    PlayingBlackJack.Deal(deck1, player, dealer);
                    PlayingBlackJack.Deal(deck1, player, dealer);

                    int menuChoice2 = 0;
                    bool checkBlack = true;
                    while (checkBlack)
                    {

                        bool endPlayer = true;
                        while (endPlayer)
                        {
                            for (int i = 0; i < player.Cards.Count; i++)
                            {

                                Console.Write("Your cards : ");
                                player.Cards[i].Display();
                            }

                            for (int i = 0; i < dealer.Cards.Count; i++)
                            {
                                if (i == 0)
                                {

                                    Console.Write("Dealer's Cards : ");
                                    dealer.Cards[i].Display(true);
                                }
                                else
                                {

                                    Console.Write("Dealer's Cards : ");
                                    dealer.Cards[i].Display();
                                }

                            }

                            //player.Cards[0].Display();
                            Console.CursorTop = 30;
                            string[] playingBlack = new string[] { "1.Hit", "2.Stand", };
                            ReadChoice("You didn't make a valid selection.", playingBlack, out menuChoice2);
                            if (menuChoice2 == 1)
                            {
                                Console.WriteLine("You selected to Hit");
                                PlayingBlackJack.Hit(deck1, player);
                                PlayingBlackJack.CheckScore(player);

                                Console.WriteLine($" Your score is :  {player.Score}");
                                Console.WriteLine("Press 1 to Hit again or press 2 to Stand");

                                if (player.Score >= 21)
                                {
                                    endPlayer = false;
                                }

                            }
                            else if (menuChoice2 == 2)
                            {
                                for (int i = 0; i < player.Cards.Count; i++)
                                {
                                    player.Cards[i].Display();
                                }

                                Console.WriteLine("You selected to Stand");
                                PlayingBlackJack.CheckScore(player);
                                Console.WriteLine($" Your score is :  {player.Score}");
                                endPlayer = false;

                            }
                            Console.ReadKey();
                        }
                        bool dealerTurn = true;
                        while (dealerTurn)
                        {
                            for (int i = 0; i < dealer.Cards.Count; i++)
                            {
                                dealer.Cards[i].Display();
                            }

                            if (!PlayingBlackJack.CheckScore(player))
                            {
                                break;
                            }
                            if (PlayingBlackJack.CheckScore(dealer, true))
                            {
                                PlayingBlackJack.Hit(deck1, dealer);
                                PlayingBlackJack.CheckScore(dealer);
                                Console.WriteLine($" The Dealer's score is :  {dealer.Score}");
                            }
                            dealerTurn = false;
                            Console.ReadKey();
                        }

                        if (player.Score > 21)
                        {
                            Console.WriteLine("You lost!");
                            break;
                        }
                        else if (dealer.Score > 21)
                        {
                            Console.WriteLine("You won!");
                            break;
                        }
                        else if (player.Score > dealer.Score)
                        {
                            Console.WriteLine("You won!");
                            break;
                        }
                        else if (player.Score < dealer.Score)
                        {
                            Console.WriteLine("You lost!");
                            break;
                        }
                        else if (player.Score == dealer.Score)
                        {
                            Console.WriteLine("You tied with the dealer!");
                            break;
                        }
                    }
                }
                else if (menuChoice == 2)
                {
                    deck1.Shuffle();
                    deck1.ShowDeck();
                }
                else if (menuChoice == 3)
                {
                    Console.WriteLine("You selected Exit");
                    check = false;
                }
                Console.ReadKey();
                Console.Clear();

            }

        }
        static int ReadInteger(string Integer)
        {
            int x = 0;

            while (true)
            {
                Console.WriteLine(Integer);
                if (Int32.TryParse(Console.ReadLine(), out x))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error!! Please try again to enter numbers 1, 2, or 3.");
                }
            }

            return x;
        }

        static void ReadChoice(string prompt, string[] options, out int selection)
        {
            foreach (string x in options)
            {
                Console.WriteLine(x);
            }
            selection = ReadInteger($"Choice:");
        }
    }
}
