﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Lab3PG2
{
    class Program
    {
        static void Main(string[] args)
        {
            //open and read the inputFile.csv file
            string fName = "inputFile.csv";
            StreamReader sr = new StreamReader(fName);
            string speech = sr.ReadToEnd();
            sr.Close();

            //create a menu
            int menuChoice = 0;
            string[] menu = new string[] { "1.Bubble Sort", "2.Merge Sort", "3.Binary Search", "4.Exit" };
            bool check = true;
            Random rng = new Random();

            //Split the string and store it in a List
            string[] comic = speech.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<string> comicList = comic.ToList();

            while (check)
            {
                ReadChoice("You didn't make a valid choice", menu, out menuChoice);
                if (menuChoice == 1)
                {
                    Console.CursorLeft = 45;
                    Console.WriteLine("Unsorted list: ");
                    foreach (var item in comic)
                    {
                        Console.WriteLine(item);
                    }
                    Console.ReadKey();
                    Console.Clear();

                    comicList = BubbleSortArrayString(comicList);
                    Console.CursorLeft = 45;
                    Console.WriteLine("Sorted List");
                    foreach (var item in comicList)
                    {
                        Console.WriteLine(item);
                    }
                   
                }
                else if (menuChoice == 2)
                {
                    Console.CursorLeft = 45;
                    Console.WriteLine("Unsorted list: ");
                    foreach (var item in comic)
                    {
                        Console.WriteLine(item);
                    }
                    Console.ReadKey();
                    Console.Clear();

                    Mergesplit(comicList);
                    Console.CursorLeft = 45;
                    Console.WriteLine("Sorted List");
                    foreach (var item in comicList)
                    {
                        Console.WriteLine(item);
                    }
            
                }
                else if (menuChoice == 3)  //binary search menu choice
                {
                    Mergesplit(comicList);
                    for (int i = 0; i < 10; i++)
                    {
                        int index = rng.Next(comicList.Count);
                        Console.Write($"{comicList[index]}    ");
                     
                        Console.Write($"Index :  {index} " );
                        
                        Console.Write("Found Index: ");
                        Console.WriteLine(Binary(comicList, 0, comicList.Count - 1, comicList[index]));
                    }
                    Console.ReadKey();
                    
                }
                else if (menuChoice == 4)
                {
                    Console.WriteLine("You have selected Exit.");
                    check = false;
                }
                Console.ReadKey();
                Console.Clear();
                
            }
        }
        
        //create a Bubble Sort
        public static List<string> BubbleSortArrayString(List<string> comicList)
        {
            List<string> bubble = comicList;
            string temp = string.Empty;
            bool x = false;
            for (int i = 0; i < bubble.Count - 1; i++)
            {
                if (bubble[i].CompareTo(bubble[i + 1]) == 1)
                {
                    temp = bubble[i];
                    bubble[i] = bubble[i + 1];
                    bubble[i + 1] = temp;
                    x = true;
                }
            }
            if (x)
            {
                BubbleSortArrayString(bubble);
            }
            return bubble;
        }

        //create a Merge Sort
        public static void Merge(List<string> comicList, List<string> left, List<string> right)
        {
            int x = 0;
            int y = 0;
            for (int i = 0; i < comicList.Count; i++)
            {
                if (y >= right.Count || (x < left.Count && left[x].CompareTo(right[y]) < 0))
                {
                    comicList[i] = left[x];
                    x++;
                }
                else
                {
                    comicList[i] = right[y];
                    y++;
                }
            }
        }

        //create a MergeSplit
        public static void Mergesplit(List<string> split)
        {
            if (split.Count > 1)
            {
                List<string> left = new List<string>(split.Count / 2);
                List<string> right = new List<string>(split.Count - split.Count / 2);
                for (int i = 0; i < right.Capacity; i++)
                {
                    right.Add(split[i + split.Count / 2]);

                }
                for (int i = 0; i < left.Capacity; i++)
                {
                    left.Add(split[i]);
                }

                Mergesplit(right);
                Mergesplit(left);
                Merge(split, right, left);

            }
        }

        //create a Binary Search using bubble or merge sorting
        private static int Binary(List<string> comicList, int min, int max, string trgt)
        {
            int middle = (max + min) / 2;
            
            if (min > max)
            {
                return -1;
            }
            else if (comicList[middle] == trgt)
            {
                return middle;
            }

            if (comicList[middle].CompareTo(trgt) > 0)
            {
                return Binary(comicList, min, middle - 1, trgt);
            }
            else if (comicList[middle].CompareTo(trgt) < 0)
            {
                return Binary(comicList, middle + 1, max, trgt);
            }
            return middle;
        }





        static void ReadChoice(string prompt, string[] options, out int selection)
        {
            foreach (string x in options)
            {
                Console.WriteLine(x);
            }
            selection = ReadInteger("Choice:");
        }

        static int ReadInteger(string Integer)
        {
            int x = 0;

            while (true)
            {
                Console.WriteLine(Integer);
                if (Int32.TryParse(Console.ReadLine(), out x))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error!! You did not make a valid input");
                }
            }

            return x;
        }
    }
}
