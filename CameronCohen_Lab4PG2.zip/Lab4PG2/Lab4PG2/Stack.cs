﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4PG2
{
    public class PG2Stack<T>
    {
        //stack will only deal with the front of list
        Node<T> head;

        //Count will keep trach of each item in list
       private int count = 0;
       public int Count { get { return count; } }

        //create a Push method that adds to the begining of list
        public T Push(T data)
        {
            Node<T> top = new Node<T>(data, null);
            top.Next = head;
            head = top;
            count++;
            head.Data = data;

            return head.Data;
        }

        //create a pop method that removes an item at the begining of list
        public T Pop()
        {
            if (head != null)
            {
                Node<T> a = head;
                head = head.Next;
                count--;
                return a.Data;
            }
            return default;
        }

        //create a Peek method that lets you look at the begining of list
        public T Peek()
        {
            return head.Data;
        }

        //create a Reverse method that will reverse the list
        public void Reverse()
        {
            Node<T> temp1 = null;
            Node<T> temp2 = head;
            Node<T> temp3 = null;

            while (temp2 != null)
            {
                temp3 = temp2.Next;
                temp2.Next = temp1;
                temp1 = temp2;
                temp2 = temp3;
            }
            head = temp1;
        }

        public string Print()
        {
            string print = string.Empty;
            Node<T> x = head;
            while (x != null)
            {
                print += $"{x.Data}";
                x = x.Next;
            }
            return print;
        }
    }
}
