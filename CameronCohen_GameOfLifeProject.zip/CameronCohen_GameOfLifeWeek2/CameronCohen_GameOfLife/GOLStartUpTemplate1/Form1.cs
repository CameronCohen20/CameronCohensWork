﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GOLStartUpTemplate1
{
    public partial class Form1 : Form
    {


        // The universe array
        bool[,] universe = new bool[5, 5];
        bool[,] scratch = new bool[5, 5];

        // Drawing colors
        Color gridColor = Color.Black;
        Color cellColor = Color.Gray;
        Color backgroundColor = Color.White;


        // The Timer class
        Timer timer = new Timer();

        // Generation count
        int generations = 0;
        
        bool drawGrid = true;

        bool showNeighbors = true;

        public Form1()
        {
            InitializeComponent();
            // Setup the timer
            timer.Interval = 100; // milliseconds
            timer.Tick += Timer_Tick;
            //read settings
            gridColor = Properties.Settings.Default.GridColor;
            cellColor = Properties.Settings.Default.CellColor;
            backgroundColor = Properties.Settings.Default.BackGroundColor;
        }

        // Calculate the next generation of cells
        private void NextGeneration()
        {
            for (int y = 0; y < scratch.GetLength(1); y++)
            {
                // Iterate through the universe in the x, left to right
                for (int x = 0; x < scratch.GetLength(0); x++)
                {
                    int count = CountNeighbors(x, y);
                    bool living = universe[x, y];
                    bool result = living;

                    //if living cells have more than 2 neighbors they die
                    if (living && count < 2)
                    {
                        result = false;
                    }
                    //if living cells have 2 or 3 neighbors they are alive
                    else if (living && (count == 2 || count == 3))
                    {
                        result = true;
                    }
                    //if living cells have more than 3 neighbors they die
                    else if (living && count > 3)
                    {
                        result = false;
                    }
                    //if dead cells have 3 neighbors they become alive
                    else if (!living && count == 3)
                    {
                        result = true;
                    }
                    scratch[x, y] = result;


                }
            }
            bool[,] temp = universe;
            universe = scratch;
            scratch = temp;
            graphicsPanel1.Invalidate();
            // Increment generation count
            generations++;

        }

        // The event called by the timer every Interval milliseconds.
        private void Timer_Tick(object sender, EventArgs e)
        {
            NextGeneration();
        }

        private void graphicsPanel1_Paint(object sender, PaintEventArgs e)
        {
            //Convert to FLOATS!
            // Calculate the width and height of each cell in pixels
            // CELL WIDTH = WINDOW WIDTH / NUMBER OF CELLS IN X
            int cellWidth = graphicsPanel1.ClientSize.Width / universe.GetLength(0);
           
            // CELL HEIGHT = WINDOW HEIGHT / NUMBER OF CELLS IN Y
            int cellHeight = graphicsPanel1.ClientSize.Height / universe.GetLength(1);
           
            // A Pen for drawing the grid lines (color, width)
            Pen gridPen = new Pen(gridColor, 1);

            // A Brush for filling living cells interiors (color)
            Brush cellBrush = new SolidBrush(cellColor);

            //Background brush for background
            Brush backgroundBrush = new SolidBrush(backgroundColor);


            // Iterate through the universe in the y, top to bottom
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                // Iterate through the universe in the x, left to right
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    
                    // A rectangle to represent each cell in pixels
                    Rectangle cellRect = Rectangle.Empty;
                    
                    
                    cellRect.X = x * cellWidth;
                    cellRect.Y = y * cellHeight;
                    cellRect.Width = cellWidth;
                    cellRect.Height = cellHeight;

                    // Fill the cell with a brush if alive
                    if (universe[x, y] == true)
                    {
                        e.Graphics.FillRectangle(cellBrush, cellRect);
                    }
                    else
                    {
                        e.Graphics.FillRectangle(backgroundBrush, cellRect);
                    }

                    // Outline the cell with a pen
                    if (drawGrid == true)
                    {
                        e.Graphics.DrawRectangle(gridPen, cellRect.X, cellRect.Y, cellRect.Width, cellRect.Height);
                    }
                    if (showNeighbors == true)
                    {
                        e.Graphics.DrawString(CountNeighbors(x, y).ToString(), graphicsPanel1.Font, Brushes.Black, cellRect.Location);
                    }



                }


            }

            toolStripStatusLabelGenerations.Text = "Generations = " + generations.ToString();
            // Cleaning up pens and brushes
            gridPen.Dispose();
            cellBrush.Dispose();
        }

        private void graphicsPanel1_MouseClick(object sender, MouseEventArgs e)
        {
            // If the left mouse button was clicked
            if (e.Button == MouseButtons.Left)
            {
                // Calculate the width and height of each cell in pixels
                int cellWidth = graphicsPanel1.ClientSize.Width / universe.GetLength(0);
                int cellHeight = graphicsPanel1.ClientSize.Height / universe.GetLength(1);

                // Calculate the cell that was clicked in
                // CELL X = MOUSE X / CELL WIDTH
                int x = e.X / cellWidth;
                // CELL Y = MOUSE Y / CELL HEIGHT
                int y = e.Y / cellHeight;

                // Toggle the cell's state
                universe[x, y] = !universe[x, y];

                // Tell Windows you need to repaint
                graphicsPanel1.Invalidate();
            }
        }



        private int CountNeighbors(int x, int y)
        {
            //make xLen and YLen the universes x and y coordinates
            int count = 0;
            int xLen = universe.GetLength(0);
            int yLen = universe.GetLength(1);

            for (int yOffset = -1; yOffset <= 1; yOffset++)
            {
                for (int xOffset = -1; xOffset <= 1; xOffset++)
                {
                    
                    int xCheck = x + xOffset;
                    int yCheck = y + yOffset;
                    if (xOffset == 0 && yOffset == 0)
                    {
                        continue;
                    }
                   
                    if (xCheck < 0)
                    {
                        continue;
                    }

                    if (yCheck < 0)
                    {
                        continue;
                    }

                    if (xCheck >= xLen)
                    {
                        continue;
                    }

                    if (yCheck >= yLen)
                    {
                        continue;
                    }

                    if (universe[xCheck, yCheck] == true) count++;
                }
            }

            return count;
        }



        private bool[,] GetLength(int v)
        {
            throw new NotImplementedException();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //starts the generation timer
            timer.Enabled = true;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //pauses the generation timer
            timer.Enabled = false;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            //skips a generation
            NextGeneration();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //exits the program
            this.Close();
        }

        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            //iterate through the universe in the y, top to bottom
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    universe[x, y] = false;
                }
            }
            generations = 0;
            // Tell Windows you need to repaint
            graphicsPanel1.Invalidate();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //iterate through the universe in the y, top to bottom
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    universe[x, y] = false;
                }
            }
            generations = 0;
            // Tell Windows you need to repaint
            graphicsPanel1.Invalidate();

        }

        private void cellColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //show colors 
            ColorDialog dlg = new ColorDialog();
            //shows the current color selected
            dlg.Color = cellColor;

            //turns the color to the changed color
            if (DialogResult.OK == dlg.ShowDialog())
            {
                cellColor = dlg.Color;
                graphicsPanel1.Invalidate();
            }

        }

        private void gridColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //show colors
            ColorDialog dlg = new ColorDialog();
            //show current color
            dlg.Color = gridColor;

            //turns the grid color into the changed color
            if (DialogResult.OK == dlg.ShowDialog())
            {
                gridColor = dlg.Color;
                graphicsPanel1.Invalidate();
            }
        }

        private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //show colors
            ColorDialog dlg = new ColorDialog();
            //show current color
            dlg.Color = backgroundColor;
            //turns the background color into the changed color
            if (DialogResult.OK == dlg.ShowDialog())
            {
                backgroundColor = dlg.Color;
                graphicsPanel1.Invalidate();
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "All Files|*.*|Cells|*.cells";
            dlg.FilterIndex = 2; dlg.DefaultExt = "cells";


            if (DialogResult.OK == dlg.ShowDialog())
            {
                StreamWriter writer = new StreamWriter(dlg.FileName);

                // Write any comments you want to include first.
                // Prefix all comment strings with an exclamation point.
                // Use WriteLine to write the strings to the file. 
                // It appends a CRLF for you.
                writer.WriteLine("!This is my comment.");


                // Create a string to represent the current row.
                String currentRow = string.Empty;
                // Iterate through the universe one row at a time.
                for (int y = 0; y < universe.GetLength(1); y++)
                {

                    // Iterate through the current row one cell at a time.
                    for (int x = 0; x < universe.GetLength(0); x++)
                    {
                        // If the universe[x,y] is alive then append 'O' (capital O)
                        // to the row string.
                        if (universe[x, y] == true)
                        {
                            currentRow = "O";

                        }
                        // Else if the universe[x,y] is dead then append '.' (period)
                        // to the row string.
                        else if (universe[x, y] == false)
                        {
                            currentRow = ".";
                        }

                    }

                    // Once the current row has been read through and the 
                    // string constructed then write it to the file using WriteLine.
                    writer.WriteLine(currentRow);
                }

                // After all rows and columns have been written then close the file.
                writer.Close();
            }

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

            //update settings
            Properties.Settings.Default.GridColor = gridColor;
            Properties.Settings.Default.CellColor = cellColor;
            Properties.Settings.Default.BackGroundColor = backgroundColor;
            Properties.Settings.Default.Save();
        }


        private void randomizeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //random generator
            Random random = new Random();
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    //make a new number generator from 0 and 2
                    int randNum = random.Next(0, 2);
                    //checks to see which cell is alive or dead
                    if (randNum == 0)
                    {
                        universe[x, y] = true;
                    }
                    else
                    {
                        universe[x, y] = false;
                    }

                }
            }
            graphicsPanel1.Invalidate();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "All Files|*.*|Cells|*.cells";
            dlg.FilterIndex = 2;

            if (DialogResult.OK == dlg.ShowDialog())
            {
                StreamReader reader = new StreamReader(dlg.FileName);

                // Create a couple variables to calculate the width and height
                // of the data in the file.
                int maxWidth = 0;
                int maxHeight = 0;

                // Iterate through the file once to get its size.
                while (!reader.EndOfStream)
                {
                    // Read one row at a time.
                    string row = reader.ReadLine();

                    // If the row begins with '!' then it is a comment
                    // and should be ignored.
                    if (row == "!")
                    {
                        continue;
                    }

                    // If the row is not a comment then it is a row of cells.
                    // Increment the maxHeight variable for each row read.
                    else
                    {
                        maxHeight++;

                    }
                    // Get the length of the current row string
                    // and adjust the maxWidth variable if necessary.
             
                }

                // Resize the current universe and scratchPad
                // to the width and height of the file calculated above.
               



                // Reset the file pointer back to the beginning of the file.
                reader.BaseStream.Seek(0, SeekOrigin.Begin);

                // Iterate through the file again, this time reading in the cells.
                while (!reader.EndOfStream)
                {
                    // Read one row at a time.
                    string row = reader.ReadLine();

                    // If the row begins with '!' then
                    // it is a comment and should be ignored.
                    if (row == "!")
                    {
                        continue;
                    }

                    // If the row is not a comment then 
                    // it is a row of cells and needs to be iterated through.
                    for (int xPos = 0; xPos < row.Length; xPos++)
                    {
                        int y = new int();
                        // If row[xPos] is a 'O' (capital O) then
                        // set the corresponding cell in the universe to alive.
                        if (row == "O")
                        {
                            universe[xPos, y] = true;
                        }
                        // If row[xPos] is a '.' (period) then
                        // set the corresponding cell in the universe to dead.
                        if (row == ".")
                        {
                            universe[xPos, y] = false;
                        }
                    }
                }

                // Close the file.
                reader.Close();
            }
        }

        private void resetToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            //Resets the settings
            Properties.Settings.Default.Reset();

            //Read Settings
            gridColor = Properties.Settings.Default.GridColor;
            cellColor = Properties.Settings.Default.CellColor;
            backgroundColor = Properties.Settings.Default.BackGroundColor;
            
            graphicsPanel1.Invalidate();
        }

        private void reloadToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            //reloads the settings
            Properties.Settings.Default.Reload();

            //Read Settings
            gridColor = Properties.Settings.Default.GridColor;
            cellColor = Properties.Settings.Default.CellColor;
            backgroundColor = Properties.Settings.Default.BackGroundColor;
            graphicsPanel1.Invalidate();
        }

        private void sizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //gets the height and the width of the universe
            int newWidth = universe.GetLength(0);
            int newHeight = universe.GetLength(1);

            Size dlg = new Size();
   
            dlg.HeightM = newHeight;
            dlg.WidthM = newWidth;

            if (DialogResult.OK == dlg.ShowDialog())
            {
                //puts the input numbers into the height and width of the universe
                newHeight = dlg.HeightM;
                newWidth = dlg.WidthM;
                //turns the inputs into the actual hiegh and width
                universe = new bool[newHeight, newWidth];
                scratch = new bool[newHeight, newWidth];
                graphicsPanel1.Invalidate();

            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //timer
            TimeDialog dlg = new TimeDialog();
            dlg.Number = timer.Interval;
            if (DialogResult.OK == dlg.ShowDialog())
            {
                //makes the timer equal to the input
                timer.Interval = dlg.Number;
                graphicsPanel1.Invalidate();
            }
        }


        private void GridOnOff_Click(object sender, EventArgs e)
        {
            
            if (GridOnOff.Checked == true)
            {
                drawGrid = true;
            }
            else if (GridOnOff.Checked == false)
            {
                drawGrid = false;
            }
            graphicsPanel1.Invalidate();
        }

        private void neighborCountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (neighborCountToolStripMenuItem.Checked == true)
            {
                showNeighbors = true;
            }
            else if (neighborCountToolStripMenuItem.Checked == false)
            {
                showNeighbors = false;
            }
            graphicsPanel1.Invalidate();
        }
    }

}
