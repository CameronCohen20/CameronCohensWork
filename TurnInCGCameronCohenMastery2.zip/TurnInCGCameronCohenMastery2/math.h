#pragma once
#include "defines.h"
#include <corecrt_math.h>

static VERTEX NDCtoScreen(VERTEX v);
static unsigned int Berp(COLOR _color, BARYCOORD coord);
static VERTEX MultiplyVerByMatrix(VERTEX v, MATRIX m);
static MATRIX BuildRotationMatrix(float r);
static VER_2D VerToVec2D(VERTEX v);






static VERTEX NDCtoScreen(VERTEX v) {
	VERTEX temp = v;

	temp.position[0] = (1 + v.position[0]) * _WIDTH / 2;

	temp.position[1] = (1 - v.position[1]) * _HEIGHT / 2;
	return temp;
}

static unsigned int Berp(COLOR _color, BARYCOORD coord) {
	int aR = (static_cast<int>(_color.x) & 0xFF000000) >> 24;
	int aG = (static_cast<int>(_color.x) & 0x00FF0000) >> 16;
	int aB = (static_cast<int>(_color.x) & 0x0000FF00) >> 8;
	int aA = (static_cast<int>(_color.x) & 0x000000FF);

	int bR = (static_cast<int>(_color.y) & 0xFF000000) >> 24;
	int bG = (static_cast<int>(_color.y) & 0x00FF0000) >> 16;
	int bB = (static_cast<int>(_color.y) & 0x0000FF00) >> 8;
	int bA = (static_cast<int>(_color.y) & 0x000000FF);

	int cR = (static_cast<int>(_color.z) & 0xFF000000) >> 24;
	int cG = (static_cast<int>(_color.z) & 0x00FF0000) >> 16;
	int cB = (static_cast<int>(_color.z) & 0x0000FF00) >> 8;
	int cA = (static_cast<int>(_color.z) & 0x000000FF);

	unsigned int fR = aR * coord.x + bR * coord.y + cR * coord.z;
	unsigned int fG = aG * coord.x + bG * coord.y + cG * coord.z;
	unsigned int fB = aB * coord.x + bB * coord.y + cB * coord.z;
	unsigned int fA = aA * coord.x + bA * coord.y + cA * coord.z;

	return (fR << 24) | (fG << 16) | (fB << 8) | (fA);
}

inline VERTEX MultiplyVerByMatrix(VERTEX v, MATRIX m)
{
	VERTEX _temp;
	_temp.color = v.color;
	_temp.position[3] = v.position[3];
	_temp.position[0] = 0;
	_temp.position[1] = 0;
	_temp.position[2] = 0;

	for (size_t i = 0; i < 3; i++)
	{
		for (size_t j = 0; j < 3; j++)
		{
			_temp.position[j] += v.position[i] * m.matrix[i][j];
		}
	}

	return _temp;

}

inline MATRIX BuildRotationMatrix(float r)
{
	MATRIX m;


	m.matrix[0][0] = cosf(r);
	m.matrix[0][1] = -sinf(r);
	m.matrix[1][0] = sinf(r);
	m.matrix[1][1] = cosf(r);
	m.matrix[2][2] = 1;

	return m;
}

inline VER_2D VerToVec2D(VERTEX v)
{
	VER_2D ver;

	ver.x = v.position[0];
	ver.y = v.position[1];

	return ver;
}



