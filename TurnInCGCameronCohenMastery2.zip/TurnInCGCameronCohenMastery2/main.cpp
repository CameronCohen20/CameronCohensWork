#include "RasterSurface.h"
#include "math.h"
#include "shaders.h"
#include "defines.h"
#include "ScreenDraw.h"
const char* _cameronCohen;



int main() {
	RS_Initialize(_cameronCohen, _WIDTH, _HEIGHT);

	float r = 0.0f;


	VERTEX Triangle[3] = {    //triangles position
		{ {0, 0.5f, 0, 0}, 0xFFFF0000}, 
		{ {0.5f, -0.5f, 0, 0}, 0xFF00FF00}, 
		{ {-0.5f, -0.2f, 0, 0}, 0xFF0000FF} 
	};

	VERTEX _lineBorder[3];


	for (int i = 0; i < 3; i++)
	{
		_lineBorder[i] = Triangle[i];

		_lineBorder[i].color = 0xFFFFFFFF;
	}




	while (RS_Update(Raster, _TOTALPIXELS))
	{
		for (size_t i = 0; i < _TOTALPIXELS; i++)
		{
			Raster[i] = 0;
		}

		VertexShader = VS_World;

		SV_WORLDMATRIX = BuildRotationMatrix(r);

		TriangleFill(Triangle[0], Triangle[1], Triangle[2]);



		ParametricLine(_lineBorder[0], _lineBorder[1]); //line 1
		ParametricLine(_lineBorder[1], _lineBorder[2]); //line 2
		ParametricLine(_lineBorder[2], _lineBorder[0]); //line 3





		r += 2 * PI / 360;

		if (r > 2 * PI) {

			r = 0;

		}
	}


	RS_Shutdown();
}